# Tvm-panel V4 — focused connection and security audit

## Changes in this archive

- **SSHX reconnect/reuse:** checks for a tracked live session and its published share URL before DNS/HTTPS preflight, so a temporary outbound-network outage does not unnecessarily break reuse of a still-live share.
- **Safer SSHX process handling:** removed the broad `pkill -x sshx` behavior. On restart, the helper terminates only the process recorded in its own PID file, avoiding disruption of unrelated SSHX sessions in the guest.
- **Browser/Termux SSH host:** the panel's SSH connection-details endpoint no longer returns `127.0.0.1`/`localhost` for a local node, because that address points to the end user's device when copied into Termux. It resolves the configured node IP/hostname and returns an actionable configuration error when no externally reachable address is configured.
- Existing per-port Cloudflare Quick Tunnel PID/log tracking is retained. Tunnel creation checks that the origin TCP port is listening, and returns diagnostic details when startup fails. Cloudflare Quick Tunnels are HTTP/HTTPS only and do not directly proxy raw SSH.
- The existing persistent Flask secret-key and login/2FA hardening described in the earlier audit remains included.

## Validation performed on this archive

- Python AST parse and bytecode compilation: **17 Python files passed**.
- Jinja parse: **78 HTML templates passed**.
- Installer shell syntax (`bash -n install.sh`): **passed**.
- ZIP archive integrity: **passed**.

## Important deployment notes

- This was a static audit and targeted patch, not a live integration test against your database, Discord bot, LXD node, public firewall, DNS, or Cloudflare/SSHX services. Those external systems cannot be verified from this archive alone.
- For Termux/direct SSH, configure the node's externally reachable public IP/hostname in **Admin → Nodes → Edit Node**. Make sure the host firewall/provider firewall allows the allocated TCP port and the guest has `openssh-server` running with the correct password.
- The SSH console returns an explicit setup error rather than a misleading localhost address if no usable node address is configured.
- SSHX and Quick Tunnel links are temporary third-party access links. Treat them as secrets; do not post them publicly. Use direct SSH + the allocated TCP port for persistent Termux access.
- Back up your database and `.env` before deploying. Keep `SECRET_KEY` stable; rotating it can invalidate sessions and encrypted node credentials.

- Added a Pinggy TCP reverse tunnel for SSH/Termux. It requires SSH listening on guest TCP/22 and outbound TCP/443; endpoint remains temporary and SSH authentication is still required. Static validation only; live provider connectivity must be tested on the actual VPS.
