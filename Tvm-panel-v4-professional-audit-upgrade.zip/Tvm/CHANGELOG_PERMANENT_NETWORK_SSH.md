# Permanent LXD Network and SSH Port Forward Fix

- Added configurable `LXD_NETWORK` (default `lxdbr0`).
- New VPS creation and OS reinstall ensure the instance NIC is attached to the managed LXD bridge before start.
- Added IPv4 discovery with retry/wait so forwarding waits for DHCP/network readiness.
- TCP and UDP port-forward devices now connect to the instance's actual IPv4 address, not host `127.0.0.1`.
- Port-forward recreation after restart/reinstall uses the current instance IPv4.
- Partial port-forward device creation is cleaned up on failure.
- Existing command decorators and menu actions are preserved.

Deployment note: The LXD host must already have a managed bridge matching `LXD_NETWORK` (default `lxdbr0`) and public ingress to allocated host ports must be permitted by the hosting provider/firewall.
