# Pinggy SSH / Termux update

- Expanded Pinggy TCP endpoint detection to support `t.ly`, `*.pinggy.io`, and `*.pinggy.link` hostnames.
- The Pinggy SSH action now clearly indicates reconnect behavior and reuses a live tracked tunnel when its endpoint is still available.
- Renamed the separate Cloudflare Quick Tunnel action to `HTTP Tunnel` to clarify that it is for HTTP services, not raw SSH.
- Added clearer UI copy for the temporary Pinggy SSH tunnel.
- Preserved the existing SSHX and HTTP tunnel functionality.

## Notes

Pinggy endpoints are temporary and depend on guest DNS and outbound TCP 443. The code has been syntax-checked, but an actual connection must be tested on the user's LXD node and network.

## Reference bot reconnect merge (2026-10-22)

- Preserved every existing Discord command: command decorator inventory remained unchanged (73 before / 73 after).
- Added a `pinggy_address` VPS database field with a safe SQLite migration for existing installations.
- Persisted the current Pinggy TCP endpoint after a successful Pinggy SSH/Reconnect action.
- Clears stale stored endpoint data when reconnect fails, so the panel does not present an old address as current.
- Kept the existing Pinggy endpoint/PID/log health check and SSHX feature; no existing commands were removed.
- Validation performed: Python compilation, ZIP integrity, command inventory comparison. Live tunnel and Termux login still require testing on the user's VPS.

