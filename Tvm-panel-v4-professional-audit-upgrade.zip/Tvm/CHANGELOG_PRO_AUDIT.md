# Professional audit upgrade

- Reworked `/health` to report degraded dependencies without falsely claiming everything is healthy; it remains a liveness endpoint so temporary LXD outages do not cause misleading process restarts.
- Added `/ready` readiness endpoint returning HTTP 503 when the database or LXD daemon cannot be reached.
- Added `ops/diagnose.sh` for safe read-only service, port, health, storage, LXD network/profile/container, and recent-log checks. It never prints `.env` contents.
- Added `ops/backup.sh` for private timestamped backups of `.env`, SQLite databases, and static uploads. The archive and checksum are created with restrictive permissions.
- Added `tests/static_check.py` to parse Python source and Jinja templates without production credentials or live infrastructure.
- Added `DEPLOYMENT_PRO.md` with deploy, network, SSH, recovery, and validation guidance.

## Verification completed here

- Python AST parse: 18 source files scanned.
- Jinja parse: 29 templates scanned.
- Python bytecode compilation: passed.
- `bash -n`: installer and both operations scripts passed.
- ZIP archive integrity test: passed.

## Not claimed as verified

No live Discord session, production DB, LXD host, node-agent API, public firewall, Termux SSH, SSHX, or Pinggy provider was accessible during this static review. Those require tests on the deployed server.
