# ZylexNode™ Panel V3 — 9.0-V3

## Fixes and improvements

- Fixed the Discord Tunnel flow to detect an actual local TCP listener before starting a Quick Tunnel.
- Added an authenticated browser terminal option on port 7681, using a dedicated non-root `zylexterm` account. Credentials are generated per launch and returned ephemerally.
- Added explicit Cloudflare URL parsing, a 60-second startup wait, per-port process/log tracking, and useful error details. The bot no longer kills every `cloudflared` process when starting one tunnel.
- Kept the existing custom HTTP tunnel behavior for other ports and clarified that Quick Tunnels are HTTP/HTTPS, not raw SSH.
- Persisted the fallback Flask secret key when `SECRET_KEY` is not configured, avoiding random key rotation on every process start.
- Updated default branding/version to ZylexNode™, release 9.0-V3, developer `rehan.404`, and prefix `4` for fresh bot configurations. Existing `.env` and database settings remain intact.

## Important

- Back up the panel database and `.env` before installing.
- This is a source-level upgrade with static validation; it cannot guarantee every production issue is fixed without testing against your actual LXD nodes, Discord settings, and network.
- Quick Tunnel URLs are temporary. Do not publish the URL or terminal password.
