# V4 Upgrade Notes

- Added `$` as an additional Discord command prefix while preserving the configured prefix (default `4`).
- Added persistent maintenance mode and read-only mode gating. Maintenance ON permits configured admins only; OFF restores normal command access.
- Added announcement command and persistent bot presence settings.
- Added admin purge workflows with short-lived confirmation, protected VPS exclusions, sequential deletion, and audit logging.
- Improved Shop provisioning status tracking and automatic wallet refund when the VPS installer reports failure.
- Fixed missing currency context in the modern Shop Manager template.
- Added missing legacy shop/order and node circuit-breaker templates to prevent TemplateNotFound errors.
- Improved panel focus states, responsive shop layouts, button states, and reduced-motion support.
- Hardened the admin VPS background installer thread so unexpected errors are persisted as failed and the event loop is closed.

Note: live Discord, provider/network, and production VPS lifecycle testing requires deployment credentials and a real host; static syntax checks do not replace that test.

- Added a Pinggy TCP reverse SSH tunnel button for Termux access, with endpoint reuse, bounded startup checks, and actionable SSH/network diagnostics.
