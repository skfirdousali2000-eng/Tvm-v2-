# Professional deployment and recovery guide

## Before updating

1. Take a backup of the current app and database. On the server, run:
   `sudo bash /opt/Tvm-panel/ops/backup.sh`
2. Keep `.env` private. It contains the Flask secret key and may contain service credentials.
3. Do not overwrite `vps.db`, `.env`, or user uploads when updating the code.

## Install/update

From the extracted `Tvm` directory:

```bash
sudo bash install.sh --dir /opt/Tvm-panel --port 5000
```

The installer keeps existing `.env`, database files, backups, and uploads. For VPS creation, LXD must be installed and initialized, and the service user must have permission to access the LXD socket. The included service currently runs as root because LXD administration requires privileged access in this deployment; treat the panel as a privileged control plane and restrict who can reach it.

## Verify deployment

```bash
sudo systemctl status Tvm-panel --no-pager
curl -fsS http://127.0.0.1:5000/health
curl -i  http://127.0.0.1:5000/ready
sudo bash /opt/Tvm-panel/ops/diagnose.sh
```

`/health` is a liveness endpoint and returns HTTP 200 when the web process responds, with dependency state in JSON. `/ready` is stricter and returns HTTP 503 if the database or LXD is unavailable.

## VPS networking checklist

- `lxc network list` should show the configured managed bridge (default `lxdbr0`).
- `lxc profile show default` should include a NIC if your deployment relies on the default profile for networking.
- Every created container should have an `eth0` NIC connected to the intended LXD bridge and receive an address/default route.
- Host outbound internet and DNS must work; guest outbound internet must also work.
- For Termux SSH, configure the node's public/reachable host and a TCP proxy/forward to guest port 22. A private `10.x`, `172.16-31.x`, or `192.168.x` guest address is not directly reachable from the public internet without routing/forwarding.
- SSHX and Pinggy endpoints are temporary third-party links. Never publish them publicly; direct SSH with a configured host/port is preferred for ongoing use.

## Safe recovery

```bash
sudo journalctl -u Tvm-panel -n 150 --no-pager
sudo systemctl restart Tvm-panel
```

If an update fails, restore the backup made before the update. Do not delete database files or run `lxc delete` as a generic troubleshooting step. Review logs for credentials and redact them before sharing.

## Validation limits

Static checks cannot prove live Discord commands, node-to-panel authentication, LXD storage, provider firewalls, public IP routing, SSH passwords, or SSHX/Pinggy provider availability. Those require checks on the actual server and network.
