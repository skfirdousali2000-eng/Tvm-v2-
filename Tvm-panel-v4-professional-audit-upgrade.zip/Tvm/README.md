# ZylexNode™ Panel V3

**Release:** 9.0-V3  
**Developer:** rehan.404

Web-based LXC VPS management panel. **Dev by tyrkrox_tech**

## One-line install (Ubuntu 20.04+ / Debian 11+, run as root)

```bash
curl -fsSL https://YOUR_HOST/install.sh | sudo bash -s -- --url https://YOUR_HOST/Tvm_panel.zip --with-lxd
```

That single command installs the system packages, downloads the panel, creates the virtualenv,
generates a secure `.env` (random `SECRET_KEY` + admin password), sets up the `Tvm-panel` systemd
service, opens the port in ufw and starts the panel. The URL and admin login are printed at the end.

> Replace `YOUR_HOST` with the place where you upload `install.sh` and the panel archive (`.zip` or `.tar.gz`).
> Drop `--with-lxd` if LXD is already installed (LXD is required to create VPS).

Same thing with process substitution:

```bash
sudo bash <(curl -fsSL https://YOUR_HOST/install.sh) --url https://YOUR_HOST/Tvm_panel.zip --with-lxd
```

### Make it even shorter
Put your archive URL inside `install.sh` once (before you upload it):

```bash
sed -i 's|^DEFAULT_ARCHIVE_URL=.*|DEFAULT_ARCHIVE_URL="https://YOUR_HOST/Tvm_panel.zip"|' install.sh
```

Then users only need:

```bash
curl -fsSL https://YOUR_HOST/install.sh | sudo bash
```

### GitHub example
Upload the panel files (with `install.sh` in the repo root) to a **public** repo, then:

```bash
curl -fsSL https://raw.githubusercontent.com/YOUR_USER/YOUR_REPO/main/install.sh | sudo bash -s -- \
  --url https://github.com/YOUR_USER/YOUR_REPO/archive/refs/heads/main.tar.gz --with-lxd
```

Anyone who knows the URLs can download the panel, so host it only where you want that. Private repos do
not work with plain `curl`.

### Verify the download (optional)
```bash
sha256sum astralhvm.zip      # run this where you built the archive
curl -fsSL https://YOUR_HOST/install.sh | sudo bash -s -- --url https://YOUR_HOST/Tvm_panel.zip --sha256 <hash>
```
The installer aborts if the hash does not match.

## Options

| Option | Default | Meaning |
|---|---|---|
| `--url URL` | – | Panel archive (`.zip` / `.tar.gz`) to download (curl mode) |
| `--sha256 HASH` | – | Verify the archive before installing |
| `--dir PATH` | `/opt/Tvm-panel` | Install location |
| `--port N` | `5000` | Panel port |
| `--name "TEXT"` | `Tvm-panel` | Panel name |
| `--admin-user NAME` | `admin` | First admin username |
| `--admin-email MAIL` | `admin@localhost` | First admin email |
| `--with-lxd` | off | Install and initialise LXD (snap) |

Environment variables `TVM_ARCHIVE_URL` and `TVM_ARCHIVE_SHA256` work like `--url` / `--sha256`.

## Manual install (from the zip)

```bash
unzip astralhvm.zip && cd astral
sudo bash install.sh --with-lxd
```

## After install

- Open `http://SERVER_IP:5000` and log in with the admin user/password printed by the installer
  (they are also in `/opt/Tvm-panel/.env`, readable by root only).
- Manage the service:

```bash
systemctl status Tvm-panel
journalctl -u Tvm-panel -f
systemctl restart Tvm-panel
```

## Configuration

Edit `/opt/Tvm-panel/.env`, then `systemctl restart Tvm-panel`.

| Variable | Meaning |
|---|---|
| `PANEL_NAME` | Name shown in the panel |
| `PORT` / `HOST` | Listen port / address |
| `SECRET_KEY` | Session + encryption key (do not change after install) |
| `YOUR_SERVER_IP` | Public IP shown in the panel |
| `MAIN_ADMIN_USERNAME` / `MAIN_ADMIN_PASSWORD` / `MAIN_ADMIN_EMAIL` | First admin; used only when the database is created |

## Discord bot (deploy VPS from Discord)

Open **Admin -> Discord Bot** in the panel, paste the bot token, your Discord user ID (main admin) and press
**Save & (re)start bot**. Optional: change the bot name, add extra admins, set member limits and the target node.

| Command | Who | What it does |
|---|---|---|
| `/register` `/deploy` `/myvps` `/vpsinfo` `/start` `/stop` `/restart` `/password` `/ostemplates` | members | create an account, deploy and manage their own VPS |
| `/allvps` `/deploy_for` `/delete` `/suspend` `/unsuspend` `/link` `/nodes` `/stats` | bot admins | manage every VPS and user |
| `/addadmin` `/removeadmin` `/botadmins` `/setname` | main admin | manage bot admins and the bot name |

Two engines are included, pick one in **Admin -> Discord Bot -> Bot engine**:

- **Custom bot (`bot.py`)** - prefix commands (`!help`), manages LXC containers directly and keeps its own `vps.db`. Token, bot name, main admin, prefix and server IP come from the panel page. It needs the *Message Content* and *Server Members* intents enabled in the Discord developer portal.
- **Panel bot (`discord_bot.py`)** - slash commands, talks to the panel's REST API so VPS appear in the panel.

The bot runs as a child process of the panel (console log: `bot_console.log`).
It needs `discord.py`, which the installer adds to the venv automatically.

## Video background

A looping animated background (`static/video/bg-loop.mp4`) is enabled by default. Change or disable it in
**Admin -> Settings -> Video background** (any direct `.mp4` URL works).

## Update

Run the same install command again. Panel files are updated; `.env`, the database, backups and uploads are kept.

## Uninstall

```bash
sudo bash /opt/Tvm-panel/install.sh uninstall     # removes the service, keeps your data
sudo rm -rf /opt/Tvm-panel                        # optional: delete everything
```

## Notes

- The installer must run as root and supports Ubuntu/Debian (apt + systemd).
- Without LXD the panel runs, but VPS cannot be created. Add it later with `sudo bash install.sh --with-lxd`.
- `node.py` is the agent for remote nodes and is installed separately on those machines.
- Logs: `Tvm.log` in the install folder and `journalctl -u Tvm-panel`.

## Admin password recovery

If the existing admin cannot sign in, activate the same Python virtualenv used by the panel and run the recovery utility from the panel folder:

```bash
cd /opt/Tvm-panel
# If multiple DB files exist, set the exact live database path first:
# export DATABASE_PATH=/opt/Tvm-panel/Tvm.db
python3 admin_recovery.py
```

The utility prompts for a new password without echoing it, updates the selected account's password hash, and restores its admin flags. It does not include a hard-coded password. Back up the live database first and make sure `DATABASE_PATH` points to the database the running panel actually uses. Restart the `Tvm-panel` service after recovery.

## Discord bot diagnostics and V3 tunnel

The custom prefix bot includes health checks and VPS diagnostics. New installs default to prefix `4`, bot/panel name `ZylexNode™`, and release `9.0-V3`; existing configured values are preserved during updates.

The Discord **Tunnel** button defaults to port `7681` and can prepare an authenticated browser terminal under the unprivileged `zylexterm` account. The temporary password is returned ephemerally in Discord and is not written to bot logs. Other ports can still be used for HTTP apps (for example `80` or `3000`). The bot checks that the origin port is listening, waits up to 60 seconds for the Quick Tunnel URL, gives actionable failure details, and uses per-port process/log files instead of killing every `cloudflared` process.

**Protocol note:** Cloudflare Quick Tunnels expose HTTP/HTTPS services. They do not directly proxy raw SSH on port `22`; use the SSH/SSHX controls for SSH access. A Quick Tunnel URL is temporary. Treat it and terminal credentials as secrets.

The fallback Flask secret key is persisted in `.secret_key` with owner-only permissions when no `SECRET_KEY` is set in the environment. Production installs should keep a stable `SECRET_KEY` in `.env` and back up the database before upgrades.

V3 validation performed for this archive: Python syntax compilation and AST parsing across application modules, shell syntax validation for the installer, archive integrity checks, and focused checks for the Tunnel handler. A live LXD/Discord/Cloudflare integration test still needs to run on your host.


## Pinggy SSH tunnel for Termux

The VPS manager includes a **🐷 Pinggy SSH** button that opens a temporary TCP reverse tunnel to the guest's SSH daemon. It returns a Termux command in the form `ssh root@HOST -p PORT`. The guest must have `openssh-server` listening on TCP port 22 and outbound TCP 443/DNS access. Use a valid SSH password or key; if root password login is disabled, connect with your configured SSH user/key. Pinggy endpoints are temporary and should be treated as secrets. Reconnect by pressing the button again if the tunnel expires.

## SSHX and reliable terminal access

The SSHX helper now uses the documented `run` mode, performs bounded DNS/HTTPS checks, waits up to 60 seconds for a share URL, and returns diagnostics if the link cannot be detected. SSHX share links are third-party temporary sessions and are not a permanent SSH endpoint. For stable Termux access, use the bot's direct SSH button and the allocated TCP port-forward (`ssh root@HOST -p PORT`). Ensure the VPS has `openssh-server` running and that the provider firewall permits the allocated TCP port. Never expose an unauthenticated root web terminal.
