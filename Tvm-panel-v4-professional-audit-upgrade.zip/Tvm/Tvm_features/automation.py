"""Automation: background worker (probe -> history -> alert rules -> auto-restart -> schedules),
alert/schedule CRUD and the per-VPS usage + uptime insights."""
import json
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta

from flask import jsonify, redirect, request, url_for, flash

from . import G, db, bad, body, api, page, render, now_iso, setting, user, audit, alert_user, vps_or_403, log
from .fleet import power_vps

SAMPLE_EVERY = 300           # seconds between stored history samples per VPS
RETENTION_DAYS = 31
METRICS = ('cpu', 'ram', 'disk', 'down')
UP, DOWN, OFF = 1, 0, 2      # sample "up" values: running / crashed-or-unreachable / powered off on purpose

_last_sample = {}
_breach = {}                 # (rule_id, vps_id) -> consecutive ticks over the limit
_fired = {}                  # (rule_id, vps_id) -> last fire time
_down_ticks = {}
_latest = {}                 # vps_id -> dict(cpu, ram, disk, up, ts)  (also used by the UI)


# ---------------------------------------------------------------------------- probing
def _probe(v):
    """-> dict(up, cpu, ram, disk) or None when we cannot tell."""
    name, node = v['container_name'], v['node_id']
    run = G['run_sync']
    try:
        st = run(G['get_container_stats'](name, node))
        if isinstance(st, dict) and st.get('status') not in ('circuit_open_cached', 'error') and 'cpu' in st:
            return {'up': UP, 'cpu': float(st.get('cpu') or 0), 'ram': float((st.get('ram') or {}).get('pct') or 0),
                    'disk': float((st.get('disk') or {}).get('pct') or 0)}
    except Exception as e:
        log.debug('stats failed for %s: %s', name, e)
    try:
        s = run(G['get_container_status'](name, node))
    except Exception:
        return None
    if s == 'running':
        return {'up': UP, 'cpu': None, 'ram': None, 'disk': None}
    if s in ('stopped', 'missing', 'frozen'):
        return {'up': DOWN, 'cpu': None, 'ram': None, 'disk': None}
    return None


def _store(vps_id, ts, p):
    with db() as c:
        c.execute('INSERT INTO vf_samples(vps_id,ts,cpu,ram,disk,up) VALUES(?,?,?,?,?,?)',
                  (vps_id, ts, p.get('cpu'), p.get('ram'), p.get('disk'), p['up']))


# ----------------------------------------------------------------------------- alerts
def _rule_applies(rule, v):
    if rule['vps_id']:
        return rule['vps_id'] == v['id']
    if rule['scope'] == 'all':
        return True
    return v['user_id'] == rule['user_id']


def _fire(rule, v, value):
    name = v.get('hostname') or v['container_name']
    m = rule['metric']
    if m == 'down':
        msg = '%s is not running (unexpected stop or unreachable).' % name
        title = 'VPS down: %s' % name
    else:
        msg = '%s on %s is %.0f%% (limit %.0f%%) for %d min.' % (m.upper(), name, value, rule['threshold'], rule['duration_min'])
        title = '%s high: %s' % (m.upper(), name)
    action = rule['action']
    with db() as c:
        recent = c.execute("SELECT COUNT(*) FROM vf_alert_events WHERE vps_id=? AND action='restart' AND created_at>=?",
                           (v['id'], (datetime.now() - timedelta(hours=1)).isoformat(timespec='seconds'))).fetchone()[0]
    limited = action == 'restart' and recent >= 3
    if limited:
        action = 'none'
        msg += ' Auto-restart skipped: already restarted 3 times in the last hour.'
    elif action == 'restart':
        msg += ' Restarting automatically...'
    with db() as c:
        c.execute('INSERT INTO vf_alert_events(rule_id,vps_id,user_id,metric,value,action,message,created_at) VALUES(?,?,?,?,?,?,?,?)',
                  (rule['id'], v['id'], rule['user_id'], m, value, action, msg, now_iso()))
        c.execute('UPDATE vf_alert_rules SET last_fired=? WHERE id=?', (now_iso(), rule['id']))
    color = 0xEF4444 if m == 'down' or value >= 95 else 0xF59E0B
    if rule['notify_panel'] or rule['notify_discord']:
        hook_only = not rule['notify_panel']
        alert_user(rule['user_id'], 'error' if color == 0xEF4444 else 'warning', title, msg, color,
                   fields=[('VPS', name), ('Metric', m), ('Value', '%.0f%%' % value if m != 'down' else 'down')], panel=not hook_only)
        if not rule['notify_discord']:
            pass
    if v['user_id'] != rule['user_id']:                         # admin-wide rule: tell the owner too
        alert_user(v['user_id'], 'warning', title, msg, color)
    if action == 'restart':
        def go():
            ok, res = power_vps(v['id'], 'restart', rule['user_id'], 'auto-restart')
            alert_user(rule['user_id'], 'success' if ok else 'error', 'Auto-restart %s: %s' % ('done' if ok else 'failed', name),
                       'Restarted by alert rule.' if ok else 'Could not restart: %s' % res,
                       0x10B981 if ok else 0xEF4444)
        threading.Thread(target=go, daemon=True).start()


def _evaluate(rules, vps_by_id, probes):
    now = time.time()
    for r in rules:
        for vid, p in probes.items():
            v = vps_by_id[vid]
            if not _rule_applies(r, v):
                continue
            key = (r['id'], vid)
            if r['metric'] == 'down':
                value = 1.0 if p['up'] == DOWN else 0.0
                over = p['up'] == DOWN
            else:
                value = p.get(r['metric'])
                if value is None:
                    continue
                over = value >= r['threshold']
            if not over:
                _breach.pop(key, None)
                continue
            _breach[key] = _breach.get(key, 0) + 1
            if _breach[key] >= max(1, r['duration_min']) and now - _fired.get(key, 0) >= r['cooldown_min'] * 60:
                _fired[key] = now
                _breach[key] = 0
                try:
                    _fire(r, v, value)
                except Exception:
                    log.exception('alert fire failed')


# -------------------------------------------------------------------------- schedules
def _run_schedules():
    utc = datetime.utcnow()
    with db() as c:
        rows = [dict(r) for r in c.execute('SELECT * FROM vf_schedules WHERE enabled=1')]
    for s in rows:
        try:
            loc = utc + timedelta(minutes=s['tz_offset'] or 0)
            if str(loc.weekday()) not in (s['days'] or '').split(','):
                continue
            hh, mm = [int(x) for x in s['at_time'].split(':')]
            due = loc.replace(hour=hh, minute=mm, second=0, microsecond=0)
            key = due.strftime('%Y-%m-%d %H:%M')
            delta = (loc - due).total_seconds()
            if not (0 <= delta < 150) or s['last_run'] == key:
                continue
            with db() as c:
                c.execute('UPDATE vf_schedules SET last_run=? WHERE id=?', (key, s['id']))
            threading.Thread(target=_do_schedule, args=(s,), daemon=True).start()
        except Exception:
            log.exception('schedule error')


def _do_schedule(s):
    vps = G['get_vps_by_id'](s['vps_id'])
    if not vps:
        return
    u = G['User'].get(s['user_id'])
    if not u or (vps['user_id'] != u.id and not u.is_admin):
        return
    cur = vps.get('status')
    if (s['action'] == 'start' and cur == 'running') or (s['action'] == 'stop' and cur == 'stopped'):
        return
    ok, msg = power_vps(vps['id'], s['action'], u.id, 'schedule')
    name = vps.get('hostname') or vps['container_name']
    if not ok:
        alert_user(u.id, 'error', 'Scheduled %s failed: %s' % (s['action'], name), msg, 0xEF4444)
    else:
        G['create_notification'](u.id, 'info', 'Scheduled %s done' % s['action'], '%s was %s by your schedule.' % (name, {'start': 'started', 'stop': 'stopped', 'restart': 'restarted'}[s['action']]))


# ---------------------------------------------------------------------------- the loop
def tick():
    now = int(time.time())
    vps_list = G['get_all_vps']()
    by_id = {v['id']: v for v in vps_list}
    for vid in [k for k in list(_last_sample) if k not in by_id]:
        _last_sample.pop(vid, None); _latest.pop(vid, None)
    running = [v for v in vps_list if v.get('status') == 'running' and not G['is_vps_suspended'](v)]
    off = [v for v in vps_list if v.get('status') in ('stopped', 'frozen') and not G['is_vps_suspended'](v)]

    probes = {}
    if running:
        with ThreadPoolExecutor(max_workers=4) as ex:
            for v, p in zip(running, ex.map(_probe_safe, running)):
                if p is not None:
                    probes[v['id']] = p
    for vid, p in probes.items():
        v = by_id[vid]
        _latest[vid] = dict(p, ts=now)
        if p['up'] == DOWN:
            _down_ticks[vid] = _down_ticks.get(vid, 0) + 1
        else:
            _down_ticks.pop(vid, None)
        due = now - _last_sample.get(vid, 0) >= SAMPLE_EVERY
        if due or (p['up'] == DOWN and _down_ticks.get(vid) == 1):
            _store(vid, now, p)
            _last_sample[vid] = now
    for v in off:
        if now - _last_sample.get(v['id'], 0) >= SAMPLE_EVERY:
            _store(v['id'], now, {'up': OFF})
            _last_sample[v['id']] = now
        _latest[v['id']] = {'up': OFF, 'ts': now}

    with db() as c:
        rules = [dict(r) for r in c.execute('SELECT * FROM vf_alert_rules WHERE enabled=1')]
    if rules and probes:
        _evaluate(rules, by_id, probes)
    _run_schedules()


def _probe_safe(v):
    try:
        return _probe(v)
    except Exception:
        return None


def _cleanup():
    cut = int(time.time()) - RETENTION_DAYS * 86400
    with db() as c:
        c.execute('DELETE FROM vf_samples WHERE ts<?', (cut,))
        c.execute('DELETE FROM vf_alert_events WHERE created_at<?', ((datetime.now() - timedelta(days=90)).isoformat(timespec='seconds'),))
        c.execute('DELETE FROM vf_alert_events WHERE id NOT IN (SELECT id FROM vf_alert_events ORDER BY id DESC LIMIT 20000)')
        c.execute('DELETE FROM vf_login_history WHERE created_at<?', ((datetime.now() - timedelta(days=90)).isoformat(timespec='seconds'),))


def _loop():
    time.sleep(25)
    last_clean = 0
    while True:
        t0 = time.time()
        try:
            tick()
            if t0 - last_clean > 86400:
                _cleanup()
                last_clean = t0
        except Exception:
            log.exception('worker tick failed')
        time.sleep(max(5.0, 60 - (time.time() - t0)))


def start_worker(app):
    if G.get('VF_DISABLE_WORKER'):
        return
    threading.Thread(target=_loop, daemon=True, name='vf-worker').start()


# ------------------------------------------------------------------------------ insights
RANGES = {'24h': (86400, 600), '7d': (7 * 86400, 3600), '30d': (30 * 86400, 6 * 3600)}


def insights(vps_id, rng):
    span, bucket = RANGES.get(rng, RANGES['24h'])
    now = int(time.time())
    since = now - span
    with db() as c:
        rows = c.execute('''SELECT (ts/?)*? AS b, AVG(cpu) cpu, MAX(cpu) cpu_max, AVG(ram) ram, AVG(disk) disk,
                   SUM(up=1) u1, SUM(up=0) u0, SUM(up=2) u2 FROM vf_samples WHERE vps_id=? AND ts>=? GROUP BY b ORDER BY b''',
                         (bucket, bucket, vps_id, since)).fetchall()
        raw = c.execute('SELECT ts, up FROM vf_samples WHERE vps_id=? AND ts>=? ORDER BY ts', (vps_id, since)).fetchall()
        ev = [dict(r) for r in c.execute('SELECT metric,value,action,message,created_at FROM vf_alert_events WHERE vps_id=? ORDER BY id DESC LIMIT 15', (vps_id,))]
    series = []
    tot1 = tot0 = 0
    for r in rows:
        u1, u0, u2 = r['u1'] or 0, r['u0'] or 0, r['u2'] or 0
        tot1 += u1; tot0 += u0
        state = 'nodata' if not (u1 or u0 or u2) else 'off' if (u1 + u0) == 0 else ('up' if u0 == 0 else 'partial' if u1 else 'down')
        series.append({'t': r['b'], 'cpu': None if r['cpu'] is None else round(r['cpu'], 1), 'cpu_max': None if r['cpu_max'] is None else round(r['cpu_max'], 1),
                       'ram': None if r['ram'] is None else round(r['ram'], 1), 'disk': None if r['disk'] is None else round(r['disk'], 1), 'state': state})
    outages, start = [], None
    for r in raw:
        if r['up'] == DOWN and start is None:
            start = r['ts']
        elif r['up'] != DOWN and start is not None:
            outages.append({'start': start, 'end': r['ts'], 'seconds': r['ts'] - start}); start = None
    if start is not None:
        outages.append({'start': start, 'end': None, 'seconds': now - start})
    return {'range': rng, 'bucket': bucket, 'series': series, 'samples': len(raw), 'uptime_pct': round(tot1 * 100.0 / (tot1 + tot0), 2) if (tot1 + tot0) else None,
            'outages': outages[-15:][::-1], 'events': ev, 'latest': _latest.get(vps_id)}


# --------------------------------------------------------------------------------- routes
def _iv(d, k, lo, hi, default):
    try:
        v = int(float(d.get(k, default)))
    except (TypeError, ValueError):
        bad('%s must be a number' % k)
    if not lo <= v <= hi:
        bad('%s must be between %s and %s' % (k, lo, hi))
    return v


def register(bp):
    @bp.route('/automation')
    @page
    def automation_page():
        cu = user()
        mine = G['get_all_vps']() if cu.is_admin else G['get_vps_for_user'](cu.id)
        names = {v['id']: (v.get('hostname') or v['container_name']) for v in mine}
        with db() as c:
            rules = [dict(r) for r in c.execute('SELECT * FROM vf_alert_rules WHERE user_id=? ORDER BY id DESC', (cu.id,))]
            scheds = [dict(r) for r in c.execute('SELECT * FROM vf_schedules WHERE user_id=? ORDER BY at_time', (cu.id,))]
            events = [dict(r) for r in c.execute('SELECT * FROM vf_alert_events WHERE user_id=? ORDER BY id DESC LIMIT 30', (cu.id,))]
            hook = c.execute('SELECT discord_webhook FROM vf_user_prefs WHERE user_id=?', (cu.id,)).fetchone()
        for r in rules:
            r['target'] = names.get(r['vps_id'], 'VPS #%s' % r['vps_id']) if r['vps_id'] else ('All VPS (panel)' if r['scope'] == 'all' else 'All my VPS')
        for s in scheds:
            s['name'] = names.get(s['vps_id'], 'VPS #%s' % s['vps_id'])
        for e in events:
            e['name'] = names.get(e['vps_id'], 'VPS #%s' % e['vps_id'])
        return render('features/automation.html', rules=rules, schedules=scheds, events=events,
                      vps_list=[{'id': k, 'name': n} for k, n in names.items()], has_webhook=bool(hook and hook[0]))

    @bp.route('/features/api/rules', methods=['POST'])
    @api
    def rule_create():
        cu = user()
        d = body()
        metric = d.get('metric')
        if metric not in METRICS:
            bad('Pick CPU, RAM, Disk or Down')
        action = d.get('action') or 'none'
        if action not in ('none', 'restart'):
            bad('Invalid action')
        if action == 'restart' and metric == 'disk':
            bad('Restarting does not fix a full disk. Use alert-only for disk.')
        vps_id = d.get('vps_id') or None
        scope = 'mine'
        if vps_id:
            vps_id = vps_or_403(vps_id)['id']
        elif d.get('scope') == 'all':
            if not cu.is_admin:
                bad('Only admins can watch every VPS on the panel', 403)
            scope = 'all'
        thr = 0 if metric == 'down' else _iv(d, 'threshold', 1, 100, 90)
        with db() as c:
            if c.execute('SELECT COUNT(*) FROM vf_alert_rules WHERE user_id=?', (cu.id,)).fetchone()[0] >= 30:
                bad('Rule limit reached (30)')
            c.execute('INSERT INTO vf_alert_rules(user_id,vps_id,scope,metric,threshold,duration_min,action,notify_discord,notify_panel,cooldown_min,enabled,created_at) '
                      'VALUES(?,?,?,?,?,?,?,?,?,?,1,?)',
                      (cu.id, vps_id, scope, metric, thr, _iv(d, 'duration_min', 1, 60, 3), action,
                       1 if d.get('notify_discord', True) else 0, 1 if d.get('notify_panel', True) else 0,
                       _iv(d, 'cooldown_min', 5, 1440, 30), now_iso()))
        audit(cu.id, 'alert_rule_create', 'alert', None, {'metric': metric, 'action': action})
        return jsonify(success=True)

    def _own(table, rid):
        with db() as c:
            r = c.execute('SELECT * FROM %s WHERE id=?' % table, (rid,)).fetchone()
        if not r or r['user_id'] != user().id:
            bad('Not found', 404)
        return r

    @bp.route('/features/api/rules/<int:rid>/toggle', methods=['POST'])
    @api
    def rule_toggle(rid):
        r = _own('vf_alert_rules', rid)
        with db() as c:
            c.execute('UPDATE vf_alert_rules SET enabled=? WHERE id=?', (0 if r['enabled'] else 1, rid))
        return jsonify(success=True)

    @bp.route('/features/api/rules/<int:rid>', methods=['DELETE'])
    @api
    def rule_delete(rid):
        _own('vf_alert_rules', rid)
        with db() as c:
            c.execute('DELETE FROM vf_alert_rules WHERE id=?', (rid,))
        return jsonify(success=True)

    @bp.route('/features/api/schedules', methods=['POST'])
    @api
    def sched_create():
        cu = user()
        d = body()
        vps = vps_or_403(d.get('vps_id'))
        if d.get('action') not in ('start', 'stop', 'restart'):
            bad('Pick start, stop or restart')
        t = str(d.get('at_time') or '')
        try:
            hh, mm = [int(x) for x in t.split(':')]
            assert 0 <= hh < 24 and 0 <= mm < 60
        except Exception:
            bad('Time must look like 14:30')
        days = sorted({int(x) for x in (d.get('days') or []) if str(x).isdigit() and 0 <= int(x) <= 6})
        if not days:
            bad('Pick at least one day')
        with db() as c:
            if c.execute('SELECT COUNT(*) FROM vf_schedules WHERE user_id=?', (cu.id,)).fetchone()[0] >= 30:
                bad('Schedule limit reached (30)')
            c.execute('INSERT INTO vf_schedules(user_id,vps_id,action,at_time,days,tz_offset,enabled,created_at) VALUES(?,?,?,?,?,?,1,?)',
                      (cu.id, vps['id'], d['action'], '%02d:%02d' % (hh, mm), ','.join(map(str, days)), _iv(d, 'tz_offset', -840, 840, 0), now_iso()))
        return jsonify(success=True)

    @bp.route('/features/api/schedules/<int:sid>/toggle', methods=['POST'])
    @api
    def sched_toggle(sid):
        r = _own('vf_schedules', sid)
        with db() as c:
            c.execute('UPDATE vf_schedules SET enabled=? WHERE id=?', (0 if r['enabled'] else 1, sid))
        return jsonify(success=True)

    @bp.route('/features/api/schedules/<int:sid>', methods=['DELETE'])
    @api
    def sched_delete(sid):
        _own('vf_schedules', sid)
        with db() as c:
            c.execute('DELETE FROM vf_schedules WHERE id=?', (sid,))
        return jsonify(success=True)

    @bp.route('/vps/<int:vps_id>/insights')
    @page
    def insights_page(vps_id):
        vps = G['get_vps_by_id'](vps_id)
        cu = user()
        if not vps or (vps['user_id'] != cu.id and not cu.is_admin):
            flash('VPS not found', 'danger')
            return redirect(url_for('vps_list'))
        return render('features/insights.html', vps=vps, vps_name=vps.get('hostname') or vps['container_name'])

    @bp.route('/features/api/insights/<int:vps_id>')
    @api
    def insights_api(vps_id):
        vps_or_403(vps_id)
        rng = request.args.get('range', '24h')
        return jsonify(success=True, **insights(vps_id, rng if rng in RANGES else '24h'))
