"""Security: real TOTP 2FA (+ recovery codes), login history, new-device alerts,
brute-force guard, user API keys page (+ expiry/scope enforcement for /api/v1)."""
import base64
import hashlib
import hmac
import json
import secrets
import struct
import time
from datetime import datetime, timedelta

from flask import jsonify, redirect, request, session, url_for, flash, render_template

from . import G, db, bad, body, api, page, render, now_iso, setting, user, audit, alert_user, valid_webhook, send_discord, log

# ------------------------------------------------------------------ TOTP (RFC 6238, stdlib only)
STEP = 30


def new_secret():
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip('=')


def _hotp(secret_b32, counter):
    key = base64.b32decode(secret_b32 + '=' * (-len(secret_b32) % 8), casefold=True)
    mac = hmac.new(key, struct.pack('>Q', counter), hashlib.sha1).digest()
    o = mac[-1] & 0x0F
    return '%06d' % ((struct.unpack('>I', mac[o:o + 4])[0] & 0x7FFFFFFF) % 1000000)


def totp_counter_match(secret_b32, code, now=None, window=1):
    """Return the matching time-step counter or None."""
    code = (code or '').strip().replace(' ', '')
    if not (len(code) == 6 and code.isdigit()):
        return None
    c = int((now if now is not None else time.time()) // STEP)
    for d in range(-window, window + 1):
        if hmac.compare_digest(_hotp(secret_b32, c + d), code):
            return c + d
    return None


def _enc(secret):
    f = G.get('encrypt_node_password')
    tok = f(secret) if f else ''
    return 'e:' + tok if tok else 'p:' + secret


def _dec(stored):
    if not stored:
        return ''
    if stored.startswith('e:'):
        return G['decrypt_node_password'](stored[2:])
    return stored[2:] if stored.startswith('p:') else stored   # tolerate raw legacy values


def _hash_code(code):
    return hashlib.sha256(code.strip().lower().replace('-', '').encode()).hexdigest()


def _new_recovery():
    codes = ['%s-%s' % (secrets.token_hex(3), secrets.token_hex(2)) for _ in range(8)]
    return codes, [_hash_code(c) for c in codes]


def verify_user_code(user_id, code):
    """TOTP (replay-protected) or a one-time recovery code. True if accepted."""
    code = (code or '').strip()
    with db() as c:
        u = c.execute('SELECT two_factor_secret FROM users WHERE id=?', (user_id,)).fetchone()
        r = c.execute('SELECT recovery, last_counter FROM vf_2fa WHERE user_id=?', (user_id,)).fetchone()
        secret = _dec(u['two_factor_secret']) if u else ''
        if secret:
            cnt = totp_counter_match(secret, code)
            last = r['last_counter'] if r else 0
            if cnt is not None and cnt > last:
                c.execute('INSERT INTO vf_2fa(user_id,last_counter) VALUES(?,?) '
                          'ON CONFLICT(user_id) DO UPDATE SET last_counter=excluded.last_counter', (user_id, cnt))
                return True
        if r and len(code.replace('-', '')) == 10:
            hashes = json.loads(r['recovery'] or '[]')
            h = _hash_code(code)
            if h in hashes:
                hashes.remove(h)
                c.execute('UPDATE vf_2fa SET recovery=? WHERE user_id=?', (json.dumps(hashes), user_id))
                return True
    return False


# ------------------------------------------------------------------------ login history
def _ip():
    return (request.remote_addr or '')[:64]


def record_login(user_id, method, success=True):
    ip, ua = _ip(), (request.user_agent.string if request else '')[:300]
    new_device = 0
    try:
        with db() as c:
            if success and user_id:
                seen = c.execute('SELECT COUNT(*) FROM vf_login_history WHERE user_id=? AND success=1', (user_id,)).fetchone()[0]
                same = c.execute('SELECT COUNT(*) FROM vf_login_history WHERE user_id=? AND success=1 AND ip=?',
                                 (user_id, ip)).fetchone()[0]
                new_device = 1 if seen and not same else 0
            c.execute('INSERT INTO vf_login_history(user_id,ip,user_agent,method,success,new_device,created_at) VALUES(?,?,?,?,?,?,?)',
                      (user_id, ip, ua, method, 1 if success else 0, new_device, now_iso()))
            if user_id and success:                                   # keep the table small
                c.execute('DELETE FROM vf_login_history WHERE user_id=? AND id NOT IN '
                          '(SELECT id FROM vf_login_history WHERE user_id=? ORDER BY id DESC LIMIT 200)', (user_id, user_id))
        if new_device:
            p = _prefs(user_id)
            if p['login_alerts']:
                alert_user(user_id, 'warning', 'Login from a new location',
                           'New sign-in from %s via %s. If this was not you, change your password and enable 2FA.' % (ip, method),
                           color=0xF59E0B, fields=[('IP', ip), ('Method', method), ('Device', ua[:120] or '?')])
    except Exception as e:
        log.warning('record_login failed: %s', e)


def _prefs(user_id):
    with db() as c:
        r = c.execute('SELECT discord_webhook, login_alerts FROM vf_user_prefs WHERE user_id=?', (user_id,)).fetchone()
    return {'discord_webhook': (r['discord_webhook'] if r else '') or '', 'login_alerts': bool(r['login_alerts']) if r else True}


def _recent_failures(ip=None, user_id=None, minutes=10):
    since = (datetime.now() - timedelta(minutes=minutes)).isoformat(timespec='seconds')
    q, a = 'SELECT COUNT(*) FROM vf_login_history WHERE success=0 AND created_at>=?', [since]
    if ip:
        q += ' AND ip=?'; a.append(ip)
    if user_id:
        q += ' AND user_id=?'; a.append(user_id)
    with db() as c:
        return c.execute(q, a).fetchone()[0]


# ------------------------------------------------------------------------------ hooks
def two_factor_view():
    """Replacement for the panel's /2fa view, which never actually checked the code."""
    uid = session.get('2fa_user_id')
    if not uid:
        return redirect(url_for('login'))
    if request.method == 'POST':
        if _recent_failures(ip=_ip()) >= 10:
            session.pop('2fa_user_id', None)
            return 'Too many failed attempts. Try again in 10 minutes.', 429
        attempts = session.get('2fa_attempts', 0) + 1
        session['2fa_attempts'] = attempts
        u = G['User'].get(uid)
        if u and verify_user_code(u.id, request.form.get('code', '')):
            session.pop('2fa_user_id', None)
            session.pop('2fa_attempts', None)
            G['login_user'](u)                       # fires user_logged_in -> history row (method 2fa)
            ts = now_iso()
            with db() as c:
                c.execute('UPDATE users SET last_login=?, last_active=? WHERE id=?', (ts, ts, u.id))
            audit(u.id, 'login', 'auth', None, {'ip': _ip(), 'method': '2fa'})
            flash('Welcome back, %s!' % u.username, 'success')
            return redirect(url_for('dashboard'))
        record_login(uid, '2fa', success=False)
        if attempts >= 5:
            session.pop('2fa_user_id', None)
            session.pop('2fa_attempts', None)
            flash('Too many wrong codes. Please sign in again.', 'danger')
            return redirect(url_for('login'))
        flash('Invalid 2FA code', 'danger')
    return render_template('2fa.html', panel_name=setting('site_name', 'tvm-panel'))


_SAFE = ('GET', 'HEAD', 'OPTIONS')


def install_hooks(app):
    # 1) real 2FA verification
    if 'two_factor' in app.view_functions:
        app.view_functions['two_factor'] = two_factor_view

    # 2) login history (password / discord / 2fa)
    try:
        from flask_login import user_logged_in

        @user_logged_in.connect_via(app)
        def _on_login(sender, user, **kw):
            ep = request.endpoint or ''
            method = {'login': 'password', 'two_factor': '2fa'}.get(ep, 'discord' if 'discord' in ep else 'other')
            record_login(user.id, method, True)
    except Exception as e:
        log.warning('login history signal not installed: %s', e)

    # 3) brute-force guard + API key expiry/scope enforcement
    @app.before_request
    def _guards():
        if request.method == 'POST' and request.endpoint == 'login':
            ident = (request.form.get('username') or '').strip()
            if _recent_failures(ip=_ip()) >= 10:
                return 'Too many failed login attempts. Try again in 10 minutes.', 429
            if ident:
                u = G['User'].get_by_username(ident) or G['User'].get_by_email(ident)
                if u and _recent_failures(user_id=u.id) >= 15:
                    return 'This account is temporarily locked after too many failed attempts. Try again in 10 minutes.', 429
        if request.path.startswith('/api/v1/'):
            key = request.headers.get('X-API-Key') or request.args.get('api_key')
            if key:
                with db() as c:
                    r = c.execute('SELECT expires_at, permissions FROM api_keys WHERE key=? AND is_active=1', (key,)).fetchone()
                if r:
                    if r['expires_at'] and r['expires_at'] < now_iso():
                        return jsonify(success=False, error='API key expired'), 401
                    try:
                        perms = json.loads(r['permissions'] or '[]')
                    except Exception:
                        perms = []
                    if perms == ['read'] and request.method not in _SAFE:
                        return jsonify(success=False, error='This API key is read-only'), 403

    @app.after_request
    def _log_failed_login(resp):
        try:
            if request.method == 'POST' and request.endpoint == 'login' and resp.status_code == 200:
                ident = (request.form.get('username') or '').strip()
                u = G['User'].get_by_username(ident) or G['User'].get_by_email(ident) if ident else None
                record_login(u.id if u else None, 'password', success=False)
        except Exception:
            pass
        return resp


# ------------------------------------------------------------------------------ routes
def register(bp):
    @bp.route('/security')
    @page
    def security_page():
        cu = user()
        with db() as c:
            hist = [dict(r) for r in c.execute(
                'SELECT * FROM vf_login_history WHERE user_id=? ORDER BY id DESC LIMIT 40', (cu.id,))]
            fails = c.execute("SELECT COUNT(*) FROM vf_login_history WHERE user_id=? AND success=0 AND created_at>=?",
                              (cu.id, (datetime.now() - timedelta(days=1)).isoformat(timespec='seconds'))).fetchone()[0]
            rec = c.execute('SELECT recovery FROM vf_2fa WHERE user_id=?', (cu.id,)).fetchone()
            en = c.execute('SELECT two_factor_enabled FROM users WHERE id=?', (cu.id,)).fetchone()
        left = len(json.loads(rec['recovery'] or '[]')) if rec else 0
        return render('features/security.html', history=hist, fails24=fails, twofa=bool(en and en[0]),
                      recovery_left=left, prefs=_prefs(cu.id), keys=_keys(cu.id))

    @bp.route('/features/api/2fa/begin', methods=['POST'])
    @api
    def twofa_begin():
        cu = user()
        sec = new_secret()
        with db() as c:
            if c.execute('SELECT two_factor_enabled FROM users WHERE id=?', (cu.id,)).fetchone()[0]:
                bad('2FA is already enabled')
            c.execute('INSERT INTO vf_2fa(user_id,pending_secret) VALUES(?,?) '
                      'ON CONFLICT(user_id) DO UPDATE SET pending_secret=excluded.pending_secret', (cu.id, _enc(sec)))
        issuer = setting('site_name', 'tvm-panel')
        from urllib.parse import quote
        uri = 'otpauth://totp/%s:%s?secret=%s&issuer=%s&digits=6&period=30' % (quote(issuer), quote(cu.username), sec, quote(issuer))
        return jsonify(success=True, secret=sec, uri=uri)

    @bp.route('/features/api/2fa/confirm', methods=['POST'])
    @api
    def twofa_confirm():
        cu = user()
        with db() as c:
            r = c.execute('SELECT pending_secret FROM vf_2fa WHERE user_id=?', (cu.id,)).fetchone()
            if not r or not r['pending_secret']:
                bad('Start the setup first')
            sec = _dec(r['pending_secret'])
            cnt = totp_counter_match(sec, body().get('code'))
            if cnt is None:
                bad('That code is wrong. Check your phone clock and try again.')
            codes, hashes = _new_recovery()
            c.execute('UPDATE vf_2fa SET pending_secret=NULL, recovery=?, last_counter=?, enabled_at=? WHERE user_id=?',
                      (json.dumps(hashes), cnt, now_iso(), cu.id))
            c.execute('UPDATE users SET two_factor_secret=?, two_factor_enabled=1 WHERE id=?', (_enc(sec), cu.id))
        audit(cu.id, '2fa_enabled', 'auth')
        alert_user(cu.id, 'success', '2FA enabled', 'Two-factor authentication is now active on your account.', 0x10B981)
        return jsonify(success=True, recovery_codes=codes)

    def _need_password_and_code(cu):
        d = body()
        row = G['User'].get(cu.id)
        if not row or not G['check_password_hash'](row.password_hash, d.get('password') or ''):
            bad('Wrong password', 403)
        if not verify_user_code(cu.id, d.get('code') or ''):
            bad('Wrong 2FA / recovery code', 403)

    @bp.route('/features/api/2fa/disable', methods=['POST'])
    @api
    def twofa_disable():
        cu = user()
        _need_password_and_code(cu)
        with db() as c:
            c.execute("UPDATE users SET two_factor_secret=NULL, two_factor_enabled=0 WHERE id=?", (cu.id,))
            c.execute("UPDATE vf_2fa SET recovery='[]', pending_secret=NULL WHERE user_id=?", (cu.id,))
        audit(cu.id, '2fa_disabled', 'auth')
        alert_user(cu.id, 'warning', '2FA disabled', 'Two-factor authentication was turned off on your account.', 0xF59E0B)
        return jsonify(success=True)

    @bp.route('/features/api/2fa/recovery', methods=['POST'])
    @api
    def twofa_recovery():
        cu = user()
        _need_password_and_code(cu)
        codes, hashes = _new_recovery()
        with db() as c:
            c.execute('UPDATE vf_2fa SET recovery=? WHERE user_id=?', (json.dumps(hashes), cu.id))
        audit(cu.id, '2fa_recovery_regenerated', 'auth')
        return jsonify(success=True, recovery_codes=codes)

    @bp.route('/features/api/prefs', methods=['POST'])
    @api
    def save_prefs():
        cu = user()
        d = body()
        hook = (d.get('discord_webhook') or '').strip()
        if hook and not valid_webhook(hook):
            bad('That does not look like a Discord webhook URL (https://discord.com/api/webhooks/...)')
        with db() as c:
            c.execute('INSERT INTO vf_user_prefs(user_id,discord_webhook,login_alerts) VALUES(?,?,?) '
                      'ON CONFLICT(user_id) DO UPDATE SET discord_webhook=excluded.discord_webhook, login_alerts=excluded.login_alerts',
                      (cu.id, hook, 1 if d.get('login_alerts', True) else 0))
        return jsonify(success=True)

    @bp.route('/features/api/prefs/test', methods=['POST'])
    @api
    def test_webhook():
        hook = (body().get('discord_webhook') or '').strip() or _prefs(user().id)['discord_webhook']
        if not valid_webhook(hook):
            bad('Save a valid Discord webhook URL first')
        ok = send_discord(hook, 'Test alert', 'Discord alerts from %s are working.' % setting('site_name', 'tvm-panel'), 0x10B981)
        if not ok:
            bad('Discord did not accept the message. Check the webhook URL.')
        return jsonify(success=True)

    # ---- user API keys (table shared with the admin/API area) ----
    @bp.route('/features/api/keys', methods=['GET'])
    @api
    def keys_list():
        return jsonify(success=True, keys=_keys(user().id))

    @bp.route('/features/api/keys', methods=['POST'])
    @api
    def keys_create():
        cu = user()
        d = body()
        name = (d.get('name') or '').strip()[:60]
        if not name:
            bad('Give the key a name')
        scope = 'read' if d.get('scope') == 'read' else 'full'
        days = int(d.get('expires_days') or 0)
        if days < 0 or days > 3650:
            bad('Expiry must be 0-3650 days')
        with db() as c:
            if c.execute('SELECT COUNT(*) FROM api_keys WHERE user_id=?', (cu.id,)).fetchone()[0] >= 20:
                bad('You can have at most 20 API keys')
            key = 'xvmpanel_' + secrets.token_urlsafe(48)
            exp = (datetime.now() + timedelta(days=days)).isoformat(timespec='seconds') if days else None
            c.execute('INSERT INTO api_keys(user_id,key,name,description,is_active,created_at,expires_at,permissions) VALUES(?,?,?,?,?,?,?,?)',
                      (cu.id, key, name, 'Created from Security page', 1, now_iso(), exp,
                       json.dumps(['read'] if scope == 'read' else ['read', 'control'])))
        audit(cu.id, 'create_api_key', 'api_key', None, {'name': name, 'scope': scope})
        return jsonify(success=True, key=key)     # shown once

    def _own_key(c, kid):
        r = c.execute('SELECT * FROM api_keys WHERE id=? AND user_id=?', (kid, user().id)).fetchone()
        if not r:
            bad('Key not found', 404)
        return r

    @bp.route('/features/api/keys/<int:kid>/toggle', methods=['POST'])
    @api
    def keys_toggle(kid):
        with db() as c:
            r = _own_key(c, kid)
            c.execute('UPDATE api_keys SET is_active=? WHERE id=?', (0 if r['is_active'] else 1, kid))
        return jsonify(success=True)

    @bp.route('/features/api/keys/<int:kid>', methods=['DELETE'])
    @api
    def keys_delete(kid):
        with db() as c:
            _own_key(c, kid)
            c.execute('DELETE FROM api_keys WHERE id=?', (kid,))
        audit(user().id, 'delete_api_key', 'api_key', kid)
        return jsonify(success=True)


def _keys(user_id):
    out = []
    with db() as c:
        for r in c.execute('SELECT id,key,name,is_active,created_at,last_used_at,expires_at,permissions FROM api_keys '
                           'WHERE user_id=? ORDER BY id DESC', (user_id,)):
            try:
                perms = json.loads(r['permissions'] or '[]')
            except Exception:
                perms = []
            out.append({'id': r['id'], 'name': r['name'], 'hint': r['key'][:9] + '…' + r['key'][-4:], 'active': bool(r['is_active']),
                        'created_at': r['created_at'], 'last_used_at': r['last_used_at'], 'expires_at': r['expires_at'],
                        'scope': 'read-only' if perms == ['read'] else 'full access',
                        'expired': bool(r['expires_at'] and r['expires_at'] < now_iso())})
    return out
