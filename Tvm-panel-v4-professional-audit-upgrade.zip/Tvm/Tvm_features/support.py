"""Support tickets: users open tickets, staff (admins) answer. Discord + panel notifications both ways."""
import re
import threading

from flask import jsonify

from . import (G, db, bad, body, api, admin_api, page, admin_page, render, now_iso, setting, user, audit, notify,
               alert_user, send_discord, valid_webhook, log)

CATS = ('general', 'billing', 'technical', 'abuse', 'other')
PRIOS = ('low', 'normal', 'high')
MAX_BODY = 4000
MAX_OPEN = 5


def _admins():
    with db() as c:
        return [r[0] for r in c.execute('SELECT id FROM users WHERE is_admin=1')]


def _tell_staff(ticket_id, subject, who, text, new):
    for aid in _admins():
        notify(aid, 'info', ('New ticket #%d' if new else 'Ticket #%d reply') % ticket_id, '%s: %s' % (who, subject[:80]))
    hook = setting('vf_support_webhook', '')
    if valid_webhook(hook):
        threading.Thread(target=send_discord, args=(
            hook, ('New ticket #%d: %s' if new else 'Reply on ticket #%d: %s') % (ticket_id, subject[:150]),
            text[:600], 0xF59E0B if new else 0x38BDF8, [('From', who)]), daemon=True).start()


def _get(c, tid):
    cu = user()
    t = c.execute('SELECT t.*, u.username FROM vf_tickets t JOIN users u ON u.id=t.user_id WHERE t.id=?', (tid,)).fetchone()
    if not t or (t['user_id'] != cu.id and not cu.is_admin):
        bad('Ticket not found', 404)
    return t


def register(bp):
    @bp.route('/support')
    @page
    def support_page():
        cu = user()
        with db() as c:
            tickets = c.execute("SELECT * FROM vf_tickets WHERE user_id=? ORDER BY CASE status WHEN 'closed' THEN 1 ELSE 0 END, updated_at DESC LIMIT 100",
                                (cu.id,)).fetchall()
        mine = [dict(id=v['id'], name=v.get('hostname') or v['container_name']) for v in G['get_vps_for_user'](cu.id)]
        return render('features/support.html', tickets=tickets, vps_list=mine, cats=CATS, prios=PRIOS)

    @bp.route('/support/<int:tid>')
    @page
    def support_ticket(tid):
        with db() as c:
            try:
                t = _get(c, tid)
            except Exception:
                return render('features/support.html', tickets=[], vps_list=[], cats=CATS, prios=PRIOS, missing=True), 404
            msgs = c.execute('SELECT m.*, u.username FROM vf_ticket_msgs m JOIN users u ON u.id=m.user_id WHERE m.ticket_id=? ORDER BY m.id', (tid,)).fetchall()
        return render('features/ticket.html', t=t, msgs=msgs, staff=bool(user().is_admin))

    @bp.route('/admin/support')
    @admin_page
    def admin_support():
        with db() as c:
            tickets = c.execute("SELECT t.*, u.username FROM vf_tickets t JOIN users u ON u.id=t.user_id "
                                "ORDER BY CASE t.status WHEN 'closed' THEN 2 WHEN 'answered' THEN 1 ELSE 0 END, "
                                "CASE t.priority WHEN 'high' THEN 0 WHEN 'normal' THEN 1 ELSE 2 END, t.updated_at DESC LIMIT 200").fetchall()
        return render('features/admin_support.html', tickets=tickets, webhook=setting('vf_support_webhook', ''))

    @bp.route('/features/api/support/new', methods=['POST'])
    @api
    def ticket_new():
        cu = user()
        d = body()
        subject = re.sub(r'\s+', ' ', str(d.get('subject') or '')).strip()[:120]
        text = str(d.get('message') or '').strip()
        cat = d.get('category') if d.get('category') in CATS else 'general'
        prio = d.get('priority') if d.get('priority') in PRIOS else 'normal'
        if len(subject) < 4:
            bad('Write a short subject (4+ characters)')
        if len(text) < 10:
            bad('Describe the problem (10+ characters)')
        if len(text) > MAX_BODY:
            bad('Message is too long (max %d characters)' % MAX_BODY)
        vps_id = None
        if d.get('vps_id'):
            v = G['get_vps_by_id'](int(d['vps_id']))
            if v and v['user_id'] == cu.id:
                vps_id = v['id']
        with db() as c:
            if c.execute("SELECT COUNT(*) FROM vf_tickets WHERE user_id=? AND status!='closed'", (cu.id,)).fetchone()[0] >= MAX_OPEN:
                bad('You already have %d open tickets, please wait for answers or close some' % MAX_OPEN, 429)
            now = now_iso()
            tid = c.execute('INSERT INTO vf_tickets(user_id,subject,category,priority,status,vps_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)',
                            (cu.id, subject, cat, prio, 'open', vps_id, now, now)).lastrowid
            c.execute('INSERT INTO vf_ticket_msgs(ticket_id,user_id,is_staff,body,created_at) VALUES(?,?,?,?,?)', (tid, cu.id, 0, text, now))
        _tell_staff(tid, subject, cu.username, text, True)
        audit(cu.id, 'ticket_new', 'ticket', tid)
        return jsonify(success=True, id=tid)

    @bp.route('/features/api/support/<int:tid>/reply', methods=['POST'])
    @api
    def ticket_reply(tid):
        cu = user()
        text = str(body().get('message') or '').strip()
        if not text:
            bad('Write a message')
        if len(text) > MAX_BODY:
            bad('Message is too long (max %d characters)' % MAX_BODY)
        with db() as c:
            t = _get(c, tid)
            staff = bool(cu.is_admin and t['user_id'] != cu.id)
            if t['status'] == 'closed' and not staff:
                bad('This ticket is closed. Open a new one if you still need help.')
            now = now_iso()
            c.execute('INSERT INTO vf_ticket_msgs(ticket_id,user_id,is_staff,body,created_at) VALUES(?,?,?,?,?)', (tid, cu.id, int(staff), text, now))
            c.execute('UPDATE vf_tickets SET status=?, updated_at=? WHERE id=?', ('answered' if staff else 'open', now, tid))
        if staff:
            alert_user(t['user_id'], 'info', 'Support replied to #%d' % tid, '%s: %s' % (t['subject'][:60], text[:300]))
        else:
            _tell_staff(tid, t['subject'], cu.username, text, False)
        return jsonify(success=True)

    @bp.route('/features/api/support/<int:tid>/status', methods=['POST'])
    @api
    def ticket_status(tid):
        cu = user()
        st = body().get('status')
        with db() as c:
            t = _get(c, tid)
            if st not in ('open', 'closed'):
                bad('Invalid status')
            if st == 'open' and not cu.is_admin and t['status'] == 'closed':
                bad('Closed tickets can only be reopened by staff')
            c.execute('UPDATE vf_tickets SET status=?, updated_at=? WHERE id=?', (st, now_iso(), tid))
        if st == 'closed' and cu.is_admin and t['user_id'] != cu.id:
            alert_user(t['user_id'], 'info', 'Ticket #%d closed' % tid, t['subject'][:100])
        return jsonify(success=True)

    @bp.route('/features/api/admin/support-settings', methods=['POST'])
    @admin_api
    def support_settings():
        hook = str(body().get('webhook') or '').strip()
        if hook and not valid_webhook(hook):
            bad('That is not a Discord webhook URL')
        G['set_setting']('vf_support_webhook', hook)
        return jsonify(success=True)
