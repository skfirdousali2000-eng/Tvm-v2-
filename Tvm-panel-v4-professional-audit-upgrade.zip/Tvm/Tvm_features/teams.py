"""Teams: group people and give the whole group access to chosen VPS.

Access is granted through the panel's own `vps.shared_with` list, so shared members get exactly what the
panel's native sharing already gives them (console, files, control). We remember which entries WE added
(vf_team_share.added=1) so removing a member or a VPS only takes back what a team gave, never a manual share.
"""
import json
import re

from flask import jsonify

from . import G, db, bad, body, api, page, render, now_iso, user, audit, notify, log

MAX_TEAMS = 10
MAX_MEMBERS = 25


def _shared(vps):
    sw = vps.get('shared_with') or []
    if isinstance(sw, str):
        try:
            sw = json.loads(sw)
        except Exception:
            sw = []
    return [int(x) for x in sw if str(x).isdigit()]


def sync_vps(vps_id):
    """Make vps.shared_with match the teams this VPS belongs to."""
    vps = G['get_vps_by_id'](int(vps_id))
    if not vps:
        return
    with db() as c:
        have = c.execute('SELECT user_id, team_id, added FROM vf_team_share WHERE vps_id=?', (vps_id,)).fetchall()
        # teams that still hold this vps, per user
        pairs = {(r[0], r[1]) for r in c.execute(
            'SELECT m.user_id, v.team_id FROM vf_team_vps v JOIN vf_team_members m ON m.team_id=v.team_id WHERE v.vps_id=?', (vps_id,))}
        shared = _shared(vps)
        changed = False
        for uid, tid in pairs:
            if uid == vps['user_id']:
                continue
            if not any(h['user_id'] == uid and h['team_id'] == tid for h in have):
                added = 0 if uid in shared else 1
                if added:
                    shared.append(uid)
                    changed = True
                c.execute('INSERT OR IGNORE INTO vf_team_share(vps_id,user_id,team_id,added) VALUES(?,?,?,?)', (vps_id, uid, tid, added))
        for h in have:
            if (h['user_id'], h['team_id']) not in pairs:
                c.execute('DELETE FROM vf_team_share WHERE vps_id=? AND user_id=? AND team_id=?', (vps_id, h['user_id'], h['team_id']))
                still = c.execute('SELECT 1 FROM vf_team_share WHERE vps_id=? AND user_id=?', (vps_id, h['user_id'])).fetchone()
                if h['added'] and not still and h['user_id'] in shared:
                    shared.remove(h['user_id'])
                    changed = True
    if changed:
        G['update_vps'](int(vps_id), shared_with=shared)


def _team_or_404(c, tid, owner_only=False):
    cu = user()
    t = c.execute('SELECT * FROM vf_teams WHERE id=?', (tid,)).fetchone()
    if not t:
        bad('Team not found', 404)
    is_member = c.execute('SELECT 1 FROM vf_team_members WHERE team_id=? AND user_id=?', (tid, cu.id)).fetchone()
    if t['owner_id'] != cu.id and not cu.is_admin and (owner_only or not is_member):
        bad('Team not found', 404)
    return t


def _team_json(c, t):
    members = [dict(id=r['user_id'], name=r['username']) for r in c.execute(
        'SELECT m.user_id, u.username FROM vf_team_members m JOIN users u ON u.id=m.user_id WHERE m.team_id=? ORDER BY u.username', (t['id'],))]
    vps = []
    for r in c.execute('SELECT vps_id FROM vf_team_vps WHERE team_id=?', (t['id'],)).fetchall():
        v = G['get_vps_by_id'](r[0])
        if v:
            vps.append(dict(id=v['id'], name=v.get('hostname') or v['container_name'], status=v.get('status'), owner_id=v['user_id']))
    owner = c.execute('SELECT username FROM users WHERE id=?', (t['owner_id'],)).fetchone()
    return dict(id=t['id'], name=t['name'], owner_id=t['owner_id'], owner=owner[0] if owner else '?', members=members, vps=vps,
                mine=t['owner_id'] == user().id or bool(user().is_admin))


def register(bp):
    @bp.route('/teams')
    @page
    def teams_page():
        cu = user()
        mine = [dict(id=v['id'], name=v.get('hostname') or v['container_name']) for v in G['get_vps_for_user'](cu.id)]
        return render('features/teams.html', my_vps=mine, uid=cu.id)

    @bp.route('/features/api/teams')
    @api
    def teams_list():
        cu = user()
        with db() as c:
            rows = c.execute('SELECT DISTINCT t.* FROM vf_teams t LEFT JOIN vf_team_members m ON m.team_id=t.id '
                             'WHERE t.owner_id=? OR m.user_id=? ORDER BY t.id', (cu.id, cu.id)).fetchall()
            return jsonify(success=True, teams=[_team_json(c, t) for t in rows])

    @bp.route('/features/api/teams', methods=['POST'])
    @api
    def teams_create():
        cu = user()
        name = re.sub(r'\s+', ' ', str(body().get('name') or '')).strip()[:40]
        if len(name) < 2:
            bad('Give the team a name (2+ characters)')
        with db() as c:
            if c.execute('SELECT COUNT(*) FROM vf_teams WHERE owner_id=?', (cu.id,)).fetchone()[0] >= MAX_TEAMS:
                bad('You can own up to %d teams' % MAX_TEAMS)
            tid = c.execute('INSERT INTO vf_teams(name,owner_id,created_at) VALUES(?,?,?)', (name, cu.id, now_iso())).lastrowid
        audit(cu.id, 'team_create', 'team', tid, {'name': name})
        return jsonify(success=True, id=tid)

    @bp.route('/features/api/teams/<int:tid>', methods=['DELETE'])
    @api
    def teams_delete(tid):
        with db() as c:
            t = _team_or_404(c, tid, owner_only=True)
            vids = [r[0] for r in c.execute('SELECT vps_id FROM vf_team_vps WHERE team_id=?', (tid,))]
            c.execute('DELETE FROM vf_team_vps WHERE team_id=?', (tid,))
            c.execute('DELETE FROM vf_team_members WHERE team_id=?', (tid,))
            c.execute('DELETE FROM vf_teams WHERE id=?', (tid,))
        for v in vids:
            sync_vps(v)
        audit(user().id, 'team_delete', 'team', tid, {'name': t['name']})
        return jsonify(success=True)

    @bp.route('/features/api/teams/<int:tid>/members', methods=['POST'])
    @api
    def team_add_member(tid):
        who = str(body().get('user') or '').strip()[:120]
        if not who:
            bad('Enter a username or email')
        with db() as c:
            t = _team_or_404(c, tid, owner_only=True)
            u = c.execute('SELECT id, username FROM users WHERE lower(username)=lower(?) OR lower(email)=lower(?)', (who, who)).fetchone()
            if not u:
                bad('No user with that username or email', 404)
            if u['id'] == t['owner_id']:
                bad('The owner is already in the team')
            if c.execute('SELECT COUNT(*) FROM vf_team_members WHERE team_id=?', (tid,)).fetchone()[0] >= MAX_MEMBERS:
                bad('A team can have up to %d members' % MAX_MEMBERS)
            if c.execute('SELECT 1 FROM vf_team_members WHERE team_id=? AND user_id=?', (tid, u['id'])).fetchone():
                bad('Already a member')
            c.execute('INSERT INTO vf_team_members(team_id,user_id,added_at) VALUES(?,?,?)', (tid, u['id'], now_iso()))
            vids = [r[0] for r in c.execute('SELECT vps_id FROM vf_team_vps WHERE team_id=?', (tid,))]
        for v in vids:
            sync_vps(v)
        notify(u['id'], 'info', 'Added to team', 'You were added to the team "%s" by %s.' % (t['name'], user().username))
        audit(user().id, 'team_add_member', 'team', tid, {'user': u['username']})
        return jsonify(success=True)

    @bp.route('/features/api/teams/<int:tid>/members/<int:uid>', methods=['DELETE'])
    @api
    def team_remove_member(tid, uid):
        cu = user()
        with db() as c:
            t = _team_or_404(c, tid)
            if t['owner_id'] != cu.id and not cu.is_admin and uid != cu.id:      # members may leave on their own
                bad('Only the team owner can remove members', 403)
            c.execute('DELETE FROM vf_team_members WHERE team_id=? AND user_id=?', (tid, uid))
            vids = [r[0] for r in c.execute('SELECT vps_id FROM vf_team_vps WHERE team_id=?', (tid,))]
        for v in vids:
            sync_vps(v)
        return jsonify(success=True)

    @bp.route('/features/api/teams/<int:tid>/vps', methods=['POST'])
    @api
    def team_add_vps(tid):
        cu = user()
        vps_id = int(body().get('vps_id') or 0)
        vps = G['get_vps_by_id'](vps_id)
        if not vps or (vps['user_id'] != cu.id and not cu.is_admin):
            bad('You can only add your own servers', 404)
        with db() as c:
            _team_or_404(c, tid, owner_only=True)
            c.execute('INSERT OR IGNORE INTO vf_team_vps(team_id,vps_id,added_by) VALUES(?,?,?)', (tid, vps_id, cu.id))
        sync_vps(vps_id)
        audit(cu.id, 'team_add_vps', 'vps', vps_id, {'team': tid})
        return jsonify(success=True)

    @bp.route('/features/api/teams/<int:tid>/vps/<int:vps_id>', methods=['DELETE'])
    @api
    def team_remove_vps(tid, vps_id):
        cu = user()
        with db() as c:
            _team_or_404(c, tid, owner_only=True)
            c.execute('DELETE FROM vf_team_vps WHERE team_id=? AND vps_id=?', (tid, vps_id))
        sync_vps(vps_id)
        return jsonify(success=True)
