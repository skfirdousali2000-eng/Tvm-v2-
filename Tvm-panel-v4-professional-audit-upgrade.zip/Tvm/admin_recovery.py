#!/usr/bin/env python3
"""Safely reset the existing Tvm-panel main admin password.

Run from the panel directory/virtualenv as the account that owns the database.
The password is requested interactively and is never printed or stored in this script.
"""
import getpass
import os
import sqlite3
import sys
from pathlib import Path

try:
    from werkzeug.security import generate_password_hash
except ImportError:
    print("Werkzeug is missing. Activate the panel virtualenv first.", file=sys.stderr)
    raise SystemExit(2)

BASE_DIR = Path(__file__).resolve().parent
configured = os.getenv("DATABASE_PATH", "").strip()
if configured:
    DB_PATH = Path(configured).expanduser()
    if not DB_PATH.is_absolute():
        DB_PATH = BASE_DIR / DB_PATH
else:
    candidates = [BASE_DIR / "hvm.db", Path.cwd() / "hvm.db", BASE_DIR / "Tvm.db", Path.cwd() / "Tvm.db"]
    existing = []
    for candidate in candidates:
        resolved = candidate.resolve()
        if resolved.exists() and resolved not in existing:
            existing.append(resolved)
    if len(existing) == 1:
        DB_PATH = existing[0]
    elif len(existing) > 1:
        print("Multiple databases found; set DATABASE_PATH to the live panel database:")
        for candidate in existing:
            print(f"  {candidate}")
        raise SystemExit(2)
    else:
        print("No panel database found. Set DATABASE_PATH to the actual Tvm.db/hvm.db path.", file=sys.stderr)
        raise SystemExit(2)

if not DB_PATH.exists():
    print(f"Database does not exist: {DB_PATH}", file=sys.stderr)
    raise SystemExit(2)

conn = sqlite3.connect(str(DB_PATH), timeout=15)
conn.row_factory = sqlite3.Row
try:
    columns = {row[1] for row in conn.execute("PRAGMA table_info(users)")}
    required = {"id", "username", "password_hash", "is_admin", "is_main_admin"}
    if not required.issubset(columns):
        print("The selected database does not look like a compatible Tvm-panel users database.", file=sys.stderr)
        raise SystemExit(2)

    rows = conn.execute("SELECT id, username, email, is_admin, is_main_admin FROM users ORDER BY id").fetchall()
    if not rows:
        print("No users exist in this database; start the panel once to initialize it first.", file=sys.stderr)
        raise SystemExit(2)
    main = [row for row in rows if row["is_main_admin"]]
    if len(main) == 1:
        target = main[0]
    else:
        print("Could not uniquely identify the main admin. Existing accounts:")
        for row in rows:
            print(f"  id={row['id']} username={row['username']!r} email={row['email']!r} admin={row['is_admin']} main_admin={row['is_main_admin']}")
        choice = input("Enter the exact username of the account to promote/reset: ").strip()
        matches = [row for row in rows if row["username"] == choice]
        if len(matches) != 1:
            print("Username did not match exactly one account; no changes made.", file=sys.stderr)
            raise SystemExit(2)
        target = matches[0]

    print(f"Selected account: {target['username']} (id={target['id']})")
    password = getpass.getpass("New admin password (input hidden): ")
    confirm = getpass.getpass("Confirm new password: ")
    if not password or password != confirm:
        print("Password is empty or the confirmation does not match; no changes made.", file=sys.stderr)
        raise SystemExit(2)
    if len(password) < 12:
        print("Warning: passwords shorter than 12 characters are easier to guess.")
        confirm_short = input("Use this short password anyway? Type YES to continue: ").strip()
        if confirm_short != "YES":
            print("Cancelled; no changes made.")
            raise SystemExit(1)

    hashed = generate_password_hash(password)
    conn.execute("BEGIN IMMEDIATE")
    conn.execute("UPDATE users SET password_hash=?, is_admin=1, is_main_admin=1 WHERE id=?", (hashed, target["id"]))
    # Ensure other accounts do not retain main-admin status if the DB was inconsistent.
    conn.execute("UPDATE users SET is_main_admin=0 WHERE id<>? AND is_main_admin<>0", (target["id"],))
    conn.commit()
    print("Admin password and admin flags updated successfully.")
    print(f"Database: {DB_PATH}")
    print("Restart the panel service, then sign in with the selected username and new password.")
except SystemExit:
    conn.rollback()
    raise
except Exception as exc:
    conn.rollback()
    print(f"Recovery failed ({type(exc).__name__}). No password value was logged.", file=sys.stderr)
    raise SystemExit(1)
finally:
    conn.close()
