#!/usr/bin/env bash
# Create a private timestamped backup of app config and SQLite databases.
set -Eeuo pipefail
APP_DIR="${APP_DIR:-/opt/Tvm-panel}"
BACKUP_DIR="${BACKUP_DIR:-$APP_DIR/backups}"
[[ $EUID -eq 0 ]] || { echo 'Run with sudo/root.' >&2; exit 1; }
[[ -d "$APP_DIR" ]] || { echo "App directory not found: $APP_DIR" >&2; exit 1; }
install -d -m 700 "$BACKUP_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
install -d -m 700 "$TMP/config" "$TMP/db"
[[ ! -f "$APP_DIR/.env" ]] || install -m 600 "$APP_DIR/.env" "$TMP/config/.env"
shopt -s nullglob
for db in "$APP_DIR"/*.db "$APP_DIR"/*.sqlite "$APP_DIR"/*.sqlite3; do
  base="$(basename "$db")"
  if command -v sqlite3 >/dev/null 2>&1; then
    sqlite3 "$db" ".timeout 10000" ".backup '$TMP/db/$base'"
  else
    cp -p "$db" "$TMP/db/$base"
  fi
done
[[ -d "$APP_DIR/static/uploads" ]] && cp -a "$APP_DIR/static/uploads" "$TMP/" || true
chmod -R go-rwx "$TMP"
tar -czf "$BACKUP_DIR/tvm-backup-$STAMP.tar.gz" -C "$TMP" .
chmod 600 "$BACKUP_DIR/tvm-backup-$STAMP.tar.gz"
sha256sum "$BACKUP_DIR/tvm-backup-$STAMP.tar.gz" > "$BACKUP_DIR/tvm-backup-$STAMP.tar.gz.sha256"
chmod 600 "$BACKUP_DIR/tvm-backup-$STAMP.tar.gz.sha256"
printf 'Backup created: %s\n' "$BACKUP_DIR/tvm-backup-$STAMP.tar.gz"
printf 'Contains configuration secrets: keep this file private and off public channels.\n'
