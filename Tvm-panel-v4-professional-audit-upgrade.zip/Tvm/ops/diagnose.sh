#!/usr/bin/env bash
# Safe read-only diagnostics for Tvm-panel. Does not print .env or credentials.
set -u
APP_DIR="${APP_DIR:-/opt/Tvm-panel}"
SERVICE="${SERVICE:-Tvm-panel}"
PORT="${PORT:-}"
if [[ -z "$PORT" && -r "$APP_DIR/.env" ]]; then
  PORT="$(sed -n 's/^PORT=//p' "$APP_DIR/.env" | tail -n1 | tr -d '"' | tr -d "'")"
fi
PORT="${PORT:-5000}"
section() { printf '\n\n===== %s =====\n' "$1"; }
run() { printf '\n$'; printf ' %q' "$@"; printf '\n'; "$@" 2>&1 || true; }
section 'Host and versions'
run date -Is
run uname -a
run python3 --version
run bash -c 'command -v lxc && lxc --version || echo "lxc: not installed/on PATH"'
section 'Service status'
run systemctl is-enabled "$SERVICE"
run systemctl is-active "$SERVICE"
run systemctl --no-pager --full status "$SERVICE"
section 'Listener and local health'
run bash -c "ss -ltnp 2>/dev/null | grep -E '(:${PORT}[[:space:]]|State)' || true"
run curl -sS --max-time 5 "http://127.0.0.1:${PORT}/health"
run curl -sS --max-time 8 "http://127.0.0.1:${PORT}/ready"
section 'Storage and permissions (no secret contents)'
run df -h "$APP_DIR"
run stat -c '%A %a %U:%G %n' "$APP_DIR" "$APP_DIR/.env" "$APP_DIR"/*.db 2>/dev/null
section 'LXD network and containers'
run bash -c 'lxc network list 2>/dev/null || true'
run bash -c 'lxc profile show default 2>/dev/null || true'
run bash -c 'lxc list 2>/dev/null || true'
section 'Recent service logs (last 100 lines; review before sharing)'
run journalctl -u "$SERVICE" -n 100 --no-pager
printf '\nDiagnostics complete. Review output for tokens, IPs, usernames, and other private data before sharing it.\n'
