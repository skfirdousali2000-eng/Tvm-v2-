(function () {
  var c = document.getElementById('fxBg');
  if (!c) return;
  var ctx = c.getContext('2d');
    var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var BG = '#0b0505', C1 = '239,68,68', C2 = '252,165,165', C3 = '251,113,133', CL = '245,139,139';
  function readTheme() { var cs = getComputedStyle(document.documentElement); function g(n, d) { var v = cs.getPropertyValue(n).trim(); return v || d; } BG = g('--zbg', BG); C1 = g('--z1-rgb', C1); C2 = g('--z2-rgb', C2); C3 = g('--z3-rgb', C3); CL = g('--zl-rgb', CL); }
  readTheme(); window.addEventListener('zx-theme', function () { readTheme(); if (reduce) draw(); });
  var W = 0, H = 0, dpr = Math.min(window.devicePixelRatio || 1, 1.5), P = [], t = 0, raf = 0;

  function shade(hex, k) {
    hex = (hex || '#0b0505').replace('#', ''); if (hex.length === 3) hex = hex.replace(/(.)/g, '$1$1');
    var n = parseInt(hex, 16), r = (n >> 16) & 255, gg = (n >> 8) & 255, b = n & 255;
    function f(v) { return Math.max(0, Math.min(255, Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k * 0.35))); }
    return 'rgb(' + f(r) + ',' + f(gg) + ',' + f(b) + ')';
  }
  function resize() {
    W = window.innerWidth; H = window.innerHeight;
    c.width = W * dpr; c.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var n = Math.max(28, Math.min(70, Math.floor(W * H / 14000)));
    P = [];
    for (var i = 0; i < n; i++) P.push({
      x: Math.random() * W, y: Math.random() * H,
      vx: (Math.random() - 0.5) * 0.25, vy: -0.1 - Math.random() * 0.3,
      r: 0.6 + Math.random() * 1.6, ph: Math.random() * 6.28
    });
  }

  function draw() {
    t += 0.016;
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, shade(BG, -0.35)); g.addColorStop(0.55, shade(BG, 0.12)); g.addColorStop(1, shade(BG, -0.1));
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    // soft blue glows
    var r1 = ctx.createRadialGradient(W * 0.2, H * 0.12, 0, W * 0.2, H * 0.12, Math.max(W, H) * 0.55);
    r1.addColorStop(0, 'rgba(' + C1 + ',0.20)'); r1.addColorStop(1, 'rgba(' + C1 + ',0)');
    ctx.fillStyle = r1; ctx.fillRect(0, 0, W, H);
    var r2 = ctx.createRadialGradient(W * 0.9, H * 0.7, 0, W * 0.9, H * 0.7, Math.max(W, H) * 0.5);
    r2.addColorStop(0, 'rgba(' + C3 + ',0.16)'); r2.addColorStop(1, 'rgba(' + C3 + ',0)');
    ctx.fillStyle = r2; ctx.fillRect(0, 0, W, H);

    // perspective grid floor
    var hz = H * 0.62, vx = W / 2;
    ctx.lineWidth = 1;
    for (var i = -14; i <= 14; i++) {
      var a = 0.05 + 0.10 * (1 - Math.abs(i) / 15);
      ctx.strokeStyle = 'rgba(' + C1 + ',' + a + ')';
      ctx.beginPath(); ctx.moveTo(vx + i * 8, hz); ctx.lineTo(vx + i * W * 0.22, H); ctx.stroke();
    }
    var off = (t * 0.35) % 1;
    for (var k = 0; k < 14; k++) {
      var p = (k + off) / 14, y = hz + (H - hz) * p * p;
      ctx.strokeStyle = 'rgba(' + C2 + ',' + (0.03 + 0.16 * p) + ')';
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }
    var hg = ctx.createLinearGradient(0, hz - 2, 0, hz + 60);
    hg.addColorStop(0, 'rgba(' + C2 + ',0.30)'); hg.addColorStop(1, 'rgba(' + C2 + ',0)');
    ctx.fillStyle = hg; ctx.fillRect(0, hz - 2, W, 60);

    // particles + links
    for (var i2 = 0; i2 < P.length; i2++) {
      var q = P[i2];
      if (!reduce) { q.x += q.vx; q.y += q.vy; }
      if (q.y < -5) { q.y = H + 5; q.x = Math.random() * W; }
      if (q.x < -5) q.x = W + 5; if (q.x > W + 5) q.x = -5;
      var tw = 0.5 + 0.5 * Math.sin(t * 1.6 + q.ph);
      ctx.fillStyle = 'rgba(' + CL + ',' + (0.25 + 0.6 * tw) + ')';
      ctx.beginPath(); ctx.arc(q.x, q.y, q.r, 0, 6.283); ctx.fill();
      for (var j = i2 + 1; j < P.length; j++) {
        var dx = q.x - P[j].x, dy = q.y - P[j].y, d = dx * dx + dy * dy;
        if (d < 12000) {
          ctx.strokeStyle = 'rgba(' + C1 + ',' + (0.16 * (1 - d / 12000)) + ')';
          ctx.beginPath(); ctx.moveTo(q.x, q.y); ctx.lineTo(P[j].x, P[j].y); ctx.stroke();
        }
      }
    }
    if (!reduce) raf = requestAnimationFrame(draw);
  }

  resize();
  window.addEventListener('resize', function () { resize(); if (reduce) draw(); });
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) cancelAnimationFrame(raf);
    else if (!reduce) { cancelAnimationFrame(raf); raf = requestAnimationFrame(draw); }
  });
  draw();
})();
