/* Theme picker: named themes (accent colours + background tone) + custom accent. Saved per browser. */
(function () {
  var KEY = 'zxTheme';
  // id, name, tagline, accent z1/z2/z3, background tone
  var THEMES = [
    { id: 'red',      name: 'Red Alert',   tag: 'Default · Red on dark',  z1: '#ef4444', z2: '#fca5a5', z3: '#fb7185', bg: '#0b0505' },
    { id: 'blue',     name: 'Neon Blue',   tag: 'Default futuristic',   z1: '#2b7fff', z2: '#22d3ee', z3: '#818cf8', bg: '#03050a' },
    { id: 'Tvm',      name: 'TVM Panel',   tag: 'Classic dark blue',    z1: '#3b82f6', z2: '#60a5fa', z3: '#8b5cf6', bg: '#0a0c10' },
    { id: 'arix',     name: 'Arix',        tag: 'Slate & indigo',       z1: '#6366f1', z2: '#a78bfa', z3: '#38bdf8', bg: '#0b0d17' },
    { id: 'nebula',   name: 'Nebula',      tag: 'Deep space purple',    z1: '#a855f7', z2: '#ec4899', z3: '#6366f1', bg: '#0a0612' },
    { id: 'cyan',     name: 'Cyber Cyan',  tag: 'Electric teal',        z1: '#06b6d4', z2: '#67e8f9', z3: '#38bdf8', bg: '#02090c' },
    { id: 'violet',   name: 'Ultra Violet',tag: 'Rich purple',          z1: '#8b5cf6', z2: '#c084fc', z3: '#6366f1', bg: '#07040f' },
    { id: 'magenta',  name: 'Synthwave',   tag: 'Retro neon',           z1: '#e879f9', z2: '#22d3ee', z3: '#fb7185', bg: '#0b0516' },
    { id: 'rose',     name: 'Crimson',     tag: 'Hot red',              z1: '#f43f5e', z2: '#fb7185', z3: '#f97316', bg: '#0b0508' },
    { id: 'lava',     name: 'Lava',        tag: 'Red to amber',         z1: '#ef4444', z2: '#f97316', z3: '#fbbf24', bg: '#0b0504' },
    { id: 'sunset',   name: 'Sunset',      tag: 'Orange glow',          z1: '#fb923c', z2: '#f43f5e', z3: '#fbbf24', bg: '#0d0705' },
    { id: 'amber',    name: 'Gold Rush',   tag: 'Gold on green-black',  z1: '#efb142', z2: '#f7cd7a', z3: '#2dd4a0', bg: '#07110d' },
    { id: 'emerald',  name: 'Matrix',      tag: 'Hacker green',         z1: '#10b981', z2: '#34d399', z3: '#a3e635', bg: '#020a06' },
    { id: 'aurora',   name: 'Aurora',      tag: 'Northern lights',      z1: '#2dd4bf', z2: '#a78bfa', z3: '#34d399', bg: '#03100f' },
    { id: 'ocean',    name: 'Deep Ocean',  tag: 'Sea blue',             z1: '#0ea5e9', z2: '#2dd4bf', z3: '#3b82f6', bg: '#020b14' },
    { id: 'midnight', name: 'Midnight',    tag: 'Dark indigo',          z1: '#4f46e5', z2: '#818cf8', z3: '#38bdf8', bg: '#02030c' },
    { id: 'sakura',   name: 'Sakura',      tag: 'Soft pink',            z1: '#f472b6', z2: '#fbcfe8', z3: '#c084fc', bg: '#0d060b' },
    { id: 'ice',      name: 'Ice',         tag: 'Cool silver',          z1: '#94a3b8', z2: '#e2e8f0', z3: '#7dd3fc', bg: '#05070a' },
    { id: 'mono',     name: 'Mono',        tag: 'Black & white',        z1: '#e5e7eb', z2: '#9ca3af', z3: '#d1d5db', bg: '#050505' }
  ];

  function h2r(h) { h = h.replace('#', ''); if (h.length === 3) h = h.replace(/(.)/g, '$1$1'); var n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function r2h(r, g, b) { return '#' + [r, g, b].map(function (v) { v = Math.max(0, Math.min(255, Math.round(v))); return ('0' + v.toString(16)).slice(-2); }).join(''); }
  function mix(a, b, t) { var x = h2r(a), y = h2r(b); return r2h(x[0] + (y[0] - x[0]) * t, x[1] + (y[1] - x[1]) * t, x[2] + (y[2] - x[2]) * t); }
  function rgbs(h) { return h2r(h).join(','); }
  function lum(h) { var c = h2r(h); return (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255; }
  function hsl(r, g, b) {
    r /= 255; g /= 255; b /= 255; var mx = Math.max(r, g, b), mn = Math.min(r, g, b), h = 0, s = 0, l = (mx + mn) / 2;
    if (mx !== mn) { var d = mx - mn; s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; }
    return [h * 360, s, l];
  }
  function hex(h, s, l) {
    h = ((h % 360) + 360) % 360 / 360;
    function f(p, q, t) { if (t < 0) t += 1; if (t > 1) t -= 1; if (t < 1 / 6) return p + (q - p) * 6 * t; if (t < .5) return q; if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6; return p; }
    var q = l < .5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    return r2h(f(p, q, h + 1 / 3) * 255, f(p, q, h) * 255, f(p, q, h - 1 / 3) * 255);
  }
  function customFrom(hexc, base) {
    var c = hsl.apply(null, h2r(hexc)), s = Math.max(.55, c[1]);
    return { id: 'custom', name: 'Custom', z1: hexc, z2: hex(c[0] + 32, s, .58), z3: hex(c[0] - 38, s, .66), bg: base.bg };
  }
  function byId(id) { for (var i = 0; i < THEMES.length; i++) if (THEMES[i].id === id) return THEMES[i]; return THEMES[0]; }
  function load() { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } }
  function save(o) { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} }
  function resolve(o) {
    if (!o) return THEMES[0];
    var base = byId(o.id);
    return o.custom ? customFrom(o.custom, base) : base;
  }

  function apply(t) {
    var r = document.documentElement.style, set = function (k, v) { r.setProperty(k, v); };
    var zl = mix(t.z1, '#ffffff', .38), zd = mix(t.z1, '#000000', .28), bg = t.bg;
    set('--z1', t.z1); set('--z2', t.z2); set('--z3', t.z3); set('--zl', zl); set('--zd', zd);
    set('--z1-rgb', rgbs(t.z1)); set('--z2-rgb', rgbs(t.z2)); set('--z3-rgb', rgbs(t.z3)); set('--zl-rgb', rgbs(zl));
    // background tone derived from the theme
    var s1 = mix(mix(bg, '#ffffff', .035), t.z1, .09), s2 = mix(bg, '#000000', .1);
    set('--zbg', bg); set('--s1-rgb', rgbs(s1)); set('--s2-rgb', rgbs(s2));
    set('--bg-primary', bg);
    set('--bg-secondary', mix(bg, t.z1, .05)); set('--bg-tertiary', mix(bg, t.z1, .09)); set('--bg-elevated', mix(bg, t.z1, .14)); set('--bg-inset', mix(bg, '#000000', .35));
    set('--border-color', mix(bg, t.z1, .2)); set('--border-light', mix(bg, t.z1, .3));
    set('--card-bg', 'rgba(' + rgbs(s1) + ', 0.72)'); set('--card-border', 'rgba(' + rgbs(t.z1) + ', 0.24)');
    set('--input-bg', mix(bg, t.z1, .06)); set('--input-border', mix(bg, t.z1, .24));
    set('--hover-bg', mix(bg, t.z1, .16)); set('--active-bg', mix(bg, t.z1, .26));
    set('--text-secondary', mix('#9db0cc', t.z1, .12)); set('--text-muted', mix('#5f7394', t.z1, .15));
    // logo letter colour: dark on light accents (Mono, Ice, Gold...), white otherwise
    set('--zlogo-fg', ((lum(t.z1) + lum(t.z2) + lum(t.z3)) / 3) > 0.6 ? '#05080f' : '#ffffff');
    try { document.documentElement.setAttribute('data-zx-theme', t.id); window.dispatchEvent(new CustomEvent('zx-theme', { detail: t })); } catch (e) {}
  }

  apply(resolve(load()));   // apply before first paint

  function build() {
    if (document.getElementById('zxPick')) return;
    var css = document.createElement('style');
    css.textContent =
      '#zxPick{position:fixed;right:14px;bottom:calc(16px + env(safe-area-inset-bottom,0px));z-index:5000}' +
      '#zxBtn{width:48px;height:48px;border-radius:50%;border:1px solid rgba(var(--z2-rgb),.6);cursor:pointer;display:grid;place-items:center;color:#fff;background:linear-gradient(135deg,var(--z1),var(--z2));box-shadow:0 0 22px rgba(var(--z1-rgb),.55);transition:transform .2s}' +
      '#zxBtn:active{transform:scale(.92)}#zxBtn svg{width:22px;height:22px}' +
      '#zxPanel{position:absolute;right:0;bottom:60px;width:min(340px,calc(100vw - 28px));max-height:min(70vh,560px);overflow:auto;padding:14px;border-radius:16px;display:none;background:rgba(4,8,18,.96);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border:1px solid rgba(var(--z2-rgb),.4);box-shadow:0 12px 40px rgba(0,0,0,.65),0 0 30px rgba(var(--z1-rgb),.25)}' +
      '#zxPick.open #zxPanel{display:block}' +
      '#zxPanel h4{margin:0 0 4px;font-size:.72rem;letter-spacing:.2em;text-transform:uppercase;color:var(--zl)}#zxPanel .sb{font-size:.74rem;color:#7d8ba3;margin-bottom:10px}' +
      '.zxG{display:grid;grid-template-columns:1fr 1fr;gap:8px}' +
      '.zxT{display:flex;flex-direction:column;gap:6px;text-align:left;padding:8px;border-radius:12px;cursor:pointer;color:#e6f0ff;font:inherit;border:1.5px solid rgba(255,255,255,.08);background:rgba(255,255,255,.03);transition:border-color .2s,transform .15s}' +
      '.zxT:active{transform:scale(.97)}.zxT.on{border-color:#fff;box-shadow:0 0 14px rgba(255,255,255,.25)}' +
      '.zxT i{display:block;height:26px;border-radius:8px;border:1px solid rgba(255,255,255,.1)}' +
      '.zxT b{font-size:.78rem;font-weight:700;line-height:1.1}.zxT small{font-size:.64rem;color:#7d8ba3;line-height:1.1;margin-top:-3px}' +
      '.zxC{display:flex;align-items:center;gap:10px;margin-top:12px;padding-top:12px;border-top:1px solid rgba(var(--z1-rgb),.25);font-size:.78rem;color:#9db0cc}' +
      '.zxC input{width:42px;height:32px;border:0;background:none;padding:0;cursor:pointer}' +
      '.zxR{margin-left:auto;background:none;border:1px solid rgba(var(--z2-rgb),.45);color:var(--zl);border-radius:8px;padding:5px 10px;font-size:.72rem;cursor:pointer}';
    document.head.appendChild(css);

    var w = document.createElement('div'); w.id = 'zxPick';
    var tiles = THEMES.map(function (t) {
      return '<button type="button" class="zxT" data-id="' + t.id + '" aria-label="' + t.name + '"><i style="background:linear-gradient(135deg,' + t.bg + ' 0%,' + t.z1 + ' 45%,' + t.z2 + ' 75%,' + t.z3 + ' 100%)"></i><b>' + t.name + '</b><small>' + t.tag + '</small></button>';
    }).join('');
    w.innerHTML =
      '<button type="button" id="zxBtn" aria-label="Change theme"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.8-.9 1.5-1.9-.3-1 .3-2.1 1.4-2.1H17a4 4 0 0 0 4-4c0-5-4-10-9-10z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7.5" r="1"/></svg></button>' +
      '<div id="zxPanel"><h4>Themes</h4><div class="sb" id="zxName"></div><div class="zxG">' + tiles + '</div>' +
      '<div class="zxC"><span>Custom accent</span><input type="color" id="zxCustom" value="#ef4444" aria-label="Custom accent colour"><button type="button" class="zxR" id="zxReset">Reset</button></div></div>';
    document.body.appendChild(w);

    var name = w.querySelector('#zxName'), cust = w.querySelector('#zxCustom');
    function mark() {
      var o = load(), t = resolve(o);
      [].forEach.call(w.querySelectorAll('.zxT'), function (b) { b.classList.toggle('on', b.getAttribute('data-id') === t.id || (t.id === 'custom' && o && b.getAttribute('data-id') === o.id)); });
      name.textContent = 'Active: ' + (o && o.custom ? byId(o.id).name + ' + custom accent' : t.name);
      cust.value = o && o.custom ? o.custom : t.z1;
    }
    w.querySelector('#zxBtn').addEventListener('click', function (e) { e.stopPropagation(); w.classList.toggle('open'); });
    document.addEventListener('click', function (e) { if (!w.contains(e.target)) w.classList.remove('open'); });
    [].forEach.call(w.querySelectorAll('.zxT'), function (b) {
      b.addEventListener('click', function () { var o = { id: b.getAttribute('data-id') }; save(o); apply(resolve(o)); mark(); });
    });
    cust.addEventListener('input', function () { var o = load() || { id: 'red' }; o = { id: o.id || 'red', custom: cust.value }; save(o); apply(resolve(o)); mark(); });
    w.querySelector('#zxReset').addEventListener('click', function () { try { localStorage.removeItem(KEY); } catch (e) {} apply(THEMES[0]); mark(); });
    mark();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})();
