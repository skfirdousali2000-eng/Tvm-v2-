#!/usr/bin/env python3
"""Static smoke checks; no production database, network, or Discord token required."""
from __future__ import annotations
import ast
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
files = sorted(ROOT.rglob('*.py'))
for path in files:
    if any(part in {'.venv', 'venv', '__pycache__'} for part in path.parts):
        continue
    try:
        ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    except (SyntaxError, UnicodeDecodeError) as exc:
        errors.append(f'{path.relative_to(ROOT)}: {exc}')
print(f'Python AST: {len(files)} source files scanned')

try:
    from jinja2 import Environment
    env = Environment()
    templates = sorted((ROOT / 'templates').glob('*.html'))
    for path in templates:
        try:
            env.parse(path.read_text(encoding='utf-8'))
        except Exception as exc:
            errors.append(f'{path.relative_to(ROOT)}: Jinja parse: {exc}')
    print(f'Jinja templates: {len(templates)} scanned')
except ImportError:
    print('Jinja2 unavailable; template parse skipped')

if errors:
    print('\nFAILURES:')
    print('\n'.join(errors))
    sys.exit(1)
print('Static smoke checks passed.')
