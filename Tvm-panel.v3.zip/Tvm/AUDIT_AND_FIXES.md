# Tvm-panel v2 — audit and login fixes

## Changes applied

- Made the fallback Flask `SECRET_KEY` persistent in `.secret_key` (created with owner-only permissions). Previously, when `SECRET_KEY` was not configured, each process start generated a new key, invalidating sessions and breaking decryption of node credentials. Keep the configured `.env` `SECRET_KEY` stable if one is already set.
- Hardened username/email login input handling and password-hash error handling.
- Prevented post-login notification/audit errors from interrupting a successful login.
- Restricted the `next` redirect to local absolute paths to avoid external redirect abuse.
- Fixed the 2FA route so it verifies a TOTP/recovery code before creating an authenticated session. Existing feature tables use replay-protected verification; older installations fall back to TOTP validation only if those tables are not available.
- Added `admin_recovery.py`, an interactive local-only recovery utility. It lists existing users, then lets the operator reset one user's password and restore admin/main-admin flags without putting the password in shell history or printing it.

## Validation performed

- Python compilation passed for all application Python files and feature modules.
- AST parsing passed for all Python files.
- This was a static code audit plus syntax validation; it is not a live integration test against your production database, node services, Discord bot, or running web server.

## If admin login still fails

1. Stop the panel service and make a backup of `Tvm.db` or `hvm.db`.
2. From the panel's `Tvm` directory, run `python3 admin_recovery.py`.
3. Select the exact admin username shown by the tool and set a strong password (12+ characters).
4. Start the service and sign in using that username and new password.
5. Ensure the service's `.env` contains a stable, high-entropy `SECRET_KEY`; do not rotate it casually because it also protects sessions and encrypted node credentials.

The recovery script changes only the selected user's password hash and admin flags. It does not delete VPS, nodes, users, or other database records.
